/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 12);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * @param {string} selector   One or more CSS selectors separated by commas
 * @param {Element} [parent]  The element to look inside of
 * @return {?Element}         The element found, if any
 */
function select(selector, parent) {
	return (parent || document).querySelector(selector);
}

/**
 * @param {string} selector   One or more CSS selectors separated by commas
 * @param {Element} [parent]  The element to look inside of
 * @return {boolean}          Whether it's been found
 */
select.exists = function (selector, parent) {
	return Boolean(select(selector, parent));
};

/**
 * @param {string} selector               One or more CSS selectors separated by commas
 * @param {Element|Element[]} [parent]    The element or list of elements to look inside of
 * @return {Element[]}                    An array of elements found
 */
select.all = function (selector, parent) {
	// Can be: select.all('selector') or select.all('selector', singleElementOrDocument)
	if (!parent || typeof parent.querySelectorAll === 'function') {
		return Array.apply(null, (parent || document).querySelectorAll(selector));
	}

	var current;
	var i;
	var ii;
	var all = [];
	for (i = 0; i < parent.length; i++) {
		current = parent[i].querySelectorAll(selector);
		for (ii = 0; ii < current.length; ii++) {
			if (all.indexOf(current[ii]) < 0) {
				all.push(current[ii]);
			}
		}
	}
	return all;
};

module.exports = select;


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const svgTagNames = __webpack_require__(24);
const classnames = __webpack_require__(25);
const flatten = __webpack_require__(26);
const omit = __webpack_require__(27);

// Copied from Preact
const IS_NON_DIMENSIONAL = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i;

const excludeSvgTags = [
	'a',
	'audio',
	'canvas',
	'iframe',
	'script',
	'video'
];

const svgTags = svgTagNames.filter(name => excludeSvgTags.indexOf(name) === -1);

const isSVG = tagName => svgTags.indexOf(tagName) >= 0;

const cloneNode = node => {
	const clone = node.cloneNode(true);

	for (const key in node) {
		if (key.indexOf('on') === 0 && typeof node[key] === 'function') {
			clone[key] = node[key];
		}
	}

	return clone;
};

const getCSSProps = attrs => {
	return Object
		.keys(attrs.style || {})
		.map(name => {
			let value = attrs.style[name];

			if (typeof value === 'number' && !IS_NON_DIMENSIONAL.test(name)) {
				value += 'px';
			}

			return {name, value};
		});
};

const getHTMLProps = attrs => {
	const allProps = omit(attrs, ['class', 'className', 'style', 'key', 'dangerouslySetInnerHTML']);

	return Object
		.keys(allProps)
		.filter(name => name.indexOf('on') !== 0)
		.map(name => ({
			name,
			value: attrs[name]
		}));
};

const getEventListeners = attrs => {
	return Object
		.keys(attrs)
		.filter(name => name.indexOf('on') === 0)
		.map(name => ({
			name: name.toLowerCase(),
			listener: attrs[name]
		}));
};

const createElement = tagName => {
	if (isSVG(tagName)) {
		return document.createElementNS('http://www.w3.org/2000/svg', tagName);
	}

	return document.createElement(tagName);
};

const setAttribute = (tagName, el, name, value) => {
	if (isSVG(tagName)) {
		el.setAttribute(name, value);
	} else {
		el.setAttributeNS(null, name, value);
	}
};

const build = (tagName, attrs, children) => {
	const el = createElement(tagName);

	const className = attrs.class || attrs.className;
	if (className) {
		setAttribute(tagName, el, 'class', classnames(className));
	}

	getCSSProps(attrs).forEach(prop => {
		el.style.setProperty(prop.name, prop.value);
	});

	getHTMLProps(attrs).forEach(prop => {
		setAttribute(tagName, el, prop.name, prop.value);
	});

	getEventListeners(attrs).forEach(event => {
		el[event.name] = event.listener;
	});

	const setHTML = attrs.dangerouslySetInnerHTML;
	if (setHTML && setHTML.__html) {
		el.innerHTML = setHTML.__html;
	} else {
		children.forEach(child => {
			el.appendChild(child);
		});
	}

	return el;
};

function h(tagName, attrs) {
	attrs = attrs || {};

	const childrenArgs = [].slice.call(arguments, 2);
	const children = flatten(childrenArgs).map(child => {
		if (child instanceof Element) {
			return cloneNode(child);
		}

		if (typeof child === 'boolean' || child === null) {
			child = '';
		}

		return document.createTextNode(child);
	});

	return build(tagName, attrs, children);
}

exports.h = h;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/bfred-it/webext-options-sync

class OptionsSync {
	constructor(storageName = 'options') {
		this.storageName = storageName;
		this.storage = chrome.storage.sync || chrome.storage.local;
	}

	define(defs) {
		defs = Object.assign({
			defaults: {},
			migrations: [],
		}, defs);

		if (chrome.runtime.onInstalled) {
			chrome.runtime.onInstalled.addListener(() => this._applyDefinition(defs));
		} else {
			this._applyDefinition(defs);
		}
	}

	_applyDefinition(defs) {
		this.getAll().then(options => {
			console.info('Existing options:', options);
			if (defs.migrations.length > 0) {
				console.info('Running', defs.migrations.length, 'migrations');
				defs.migrations.forEach(migrate => migrate(options, defs.defaults));
			}
			const newOptions = Object.assign(defs.defaults, options);
			this.setAll(newOptions);
		});
	}

	_parseNumbers(options) {
		for (const name of Object.keys(options)) {
			if (options[name] === String(Number(options[name]))) {
				options[name] = Number(options[name]);
			}
		}
		return options;
	}

	getAll() {
		return new Promise(resolve => {
			this.storage.get(this.storageName,
				keys => resolve(keys[this.storageName] || {})
			);
		}).then(this._parseNumbers);
	}

	setAll(newOptions) {
		return new Promise(resolve => {
			this.storage.set({
				[this.storageName]: newOptions,
			}, resolve);
		});
	}

	set(newOptions) {
		return this.getAll().then(options => {
			this.setAll(Object.assign(options, newOptions));
		});
	}

	syncForm(form) {
		if (typeof form === 'string') {
			form = document.querySelector(form);
		}
		this.getAll().then(options => OptionsSync._applyToForm(options, form));
		form.addEventListener('input', e => this._handleFormUpdates(e));
		form.addEventListener('change', e => this._handleFormUpdates(e));
	}

	static _applyToForm(options, form) {
		for (const name of Object.keys(options)) {
			const els = form.querySelectorAll(`[name="${name}"]`);
			const [field] = els;
			if (field) {
				console.info('Set option', name, 'to', options[name]);
				switch (field.type) {
					case 'checkbox':
						field.checked = options[name];
						break;
					case 'radio': {
						const [selected] = Array.from(els)
						.filter(el => el.value === options[name]);
						if (selected) {
							selected.checked = true;
						}
						break;
					}
					default:
						field.value = options[name];
						break;
				}
			} else {
				console.warn('Stored option {', name, ':', options[name], '} was not found on the page');
			}
		}
	}

	_handleFormUpdates(e) {
		const el = e.target;
		const name = el.name;
		let value = el.value;
		if (!name) {
			return;
		}
		switch (el.type) {
			case 'select-one':
				value = el.options[el.selectedIndex].value;
				break;
			case 'checkbox':
				value = el.checked;
				break;
			default: break;
		}
		console.info('Saving option', el.name, 'to', value);
		this.set({
			[name]: value,
		});
	}
}

OptionsSync.migrations = {
	removeUnused(options, defaults) {
		for (const key of Object.keys(options)) {
			if (!(key in defaults)) {
				delete options[key];
			}
		}
	}
};

if (true) {
	module.exports = OptionsSync;
}


/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_webext_content_script_ping__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_webext_content_script_ping___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_webext_content_script_ping__);


function logRuntimeErrors() {
	if (chrome.runtime.lastError) {
		console.error(chrome.runtime.lastError);
	}
}

async function injectContentScript(script, tabId) {
	const allFrames = script.all_frames;
	const runAt = script.run_at;
	script.css.forEach(file => chrome.tabs.insertCSS(tabId, {file, allFrames, runAt}, logRuntimeErrors));
	script.js.forEach(file => chrome.tabs.executeScript(tabId, {file, allFrames, runAt}, logRuntimeErrors));
}

async function injectContentScripts(tab) {
	// Get the tab object if we don't have it already
	if (!tab.id) {
		tab = await new Promise(resolve => chrome.tabs.get(tab, resolve));
		logRuntimeErrors();
	}

	// If we don't have the URL, we definitely can't access it.
	if (!tab.url) {
		return;
	}

	// We might just get the url because of the `tabs` permission,
	// not necessarily because we have access to the origin.
	// This will explicitly verify this permission.
	const isPermitted = await new Promise(resolve => chrome.permissions.contains({
		origins: [new URL(tab.url).origin + '/']
	}, resolve));
	logRuntimeErrors();

	if (!isPermitted) {
		return;
	}

	// Exit if already injected
	try {
		return await Object(__WEBPACK_IMPORTED_MODULE_0_webext_content_script_ping__["pingContentScript"])(tab.id || tab);
	} catch (err) {}

	chrome.runtime.getManifest().content_scripts.forEach(s => injectContentScript(s, tab.id));
}

/* harmony default export */ __webpack_exports__["a"] = (function (tab = false) {
	if (tab === false) {
		chrome.tabs.onUpdated.addListener((tabId, {status}) => {
			if (status === 'loading') {
				injectContentScripts(tabId);
			}
		});
	} else {
		injectContentScripts(tab);
	}
});


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

// https://github.com/bfred-it/webext-content-script-ping

function pingContentScript(tab) {
	return new Promise((resolve, reject) => {
		setTimeout(reject, 300);
		chrome.tabs.sendMessage(tab.id || tab, chrome.runtime.id, {
			// Only the main frame is necessary;
			// if that isn't loaded, no other iframe is
			frameId: 0
		}, response => {
			if (response === chrome.runtime.id) {
				resolve();
			} else {
				reject();
			}
		});
	});
}

if (!chrome.runtime.getBackground) {
	// Respond to pings
	chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
		if (request === chrome.runtime.id) {
			sendResponse(chrome.runtime.id);
		}
	});
}

if (true) {
	exports.pingContentScript = pingContentScript;
}


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = input => {
	const el = document.createElement('textarea');

	el.value = input;

	// Prevent keyboard from showing on mobile
	el.setAttribute('readonly', '');

	el.style.contain = 'strict';
	el.style.position = 'absolute';
	el.style.left = '-9999px';
	el.style.fontSize = '12pt'; // Prevent zooming on iOS

	const selection = getSelection();
	let originalRange = false;
	if (selection.rangeCount > 0) {
		originalRange = selection.getRangeAt(0);
	}

	document.body.appendChild(el);
	el.select();

	let success = false;
	try {
		success = document.execCommand('copy');
	} catch (err) {}

	document.body.removeChild(el);

	if (originalRange) {
		selection.removeAllRanges();
		selection.addRange(originalRange);
	}

	return success;
};


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const PCancelable = __webpack_require__(13);

const selectorCache = new Map();

module.exports = selector => {
	if (selectorCache.has(selector)) {
		return selectorCache.get(selector);
	}

	const promise = new PCancelable((onCancel, resolve) => {
		let raf;
		onCancel(() => {
			cancelAnimationFrame(raf);
		});

		// Interval to keep checking for it to come into the DOM
		(function check() {
			const el = document.querySelector(selector);

			if (el) {
				resolve(el);
				selectorCache.delete(selector);
			} else {
				raf = requestAnimationFrame(check);
			}
		})();
	});

	selectorCache.set(selector, promise);

	return promise;
};


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var gitHubInjection = function (global, cb) {
  if (!global) {
    throw new Error('Missing argument global');
  }

  if (!global.document || !global.document.getElementById) {
    throw new Error('The given argument global is not a valid window object');
  }

  if (!cb) {
    throw new Error('Missing argument callback');
  }

  if (typeof cb !== 'function') {
    throw new Error('Callback is not a function');
  }

  var domElement = global.document.getElementById('js-repo-pjax-container') ||
    global.document.getElementById('js-pjax-container');
  if (!domElement || !global.MutationObserver) {
    return cb(null);
  }

  var viewSpy = new global.MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      if (mutation.type === 'childList' && mutation.addedNodes.length) {
        cb(null);
      }
    });
  });

  viewSpy.observe(domElement, {
    attributes: true,
    childList: true,
    characterData: true
  });

  cb(null);
};

// Export the gitHubInjection function for **Node.js**, with
// backwards-compatibility for the old `require()` API. If we're in
// the browser, add `gitHubInjection` as a global object.
if (true) {
  if (typeof module !== 'undefined' && module.exports) {
    exports = module.exports = gitHubInjection;
  }
  exports.gitHubInjection = gitHubInjection;
} else {
  /*jshint -W040 */
  this.gitHubInjection = gitHubInjection;
  /*jshint +W040 */
}


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* globals document */

const issueRegex = __webpack_require__(19);
const createHtmlElement = __webpack_require__(9);

const groupedIssueRegex = new RegExp(`(${issueRegex().source})`, 'g');

// Get <a> element as string
const linkify = (match, options) => {
	let url = `${options.baseUrl}/`;
	if (match.includes('/')) {
		const parts = match.split('#');
		url += `${parts[0]}/issues/${parts[1]}`;
	} else {
		url += `${options.user}/${options.repo}/issues/${match.slice(1)}`;
	}

	return createHtmlElement({
		name: 'a',
		attributes: Object.assign({href: ''}, options.attributes, {href: url}),
		value: match
	});
};

// Get DOM node from HTML
const domify = html => document.createRange().createContextualFragment(html);

const getAsString = (input, options) => {
	return input.replace(groupedIssueRegex, match => linkify(match, options));
};

const getAsDocumentFragment = (input, options) => {
	return input.split(groupedIssueRegex).reduce((frag, text, index) => {
		if (index % 2) { // URLs are always in odd positions
			frag.appendChild(domify(linkify(text, options)));
		} else if (text.length > 0) {
			frag.appendChild(document.createTextNode(text));
		}

		return frag;
	}, document.createDocumentFragment());
};

module.exports = (input, options) => {
	options = Object.assign({
		attributes: {},
		baseUrl: 'https://github.com',
		type: 'string'
	}, options);

	if (!(options.user && options.repo)) {
		throw new Error('Missing required `user` and `repo` options');
	}

	if (options.type === 'string') {
		return getAsString(input, options);
	}

	if (options.type === 'dom') {
		return getAsDocumentFragment(input, options);
	}

	throw new Error('The type option must be either dom or string');
};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const stringifyAttributes = __webpack_require__(20);
const htmlTags = __webpack_require__(22);

const voidHtmlTags = new Set(htmlTags);

module.exports = options => {
	options = Object.assign({
		name: 'div',
		attributes: {},
		value: ''
	}, options);

	let ret = `<${options.name}${stringifyAttributes(options.attributes)}>`;

	if (!voidHtmlTags.has(options.name)) {
		ret += `${options.value}</${options.name}>`;
	}

	return ret;
};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = new Promise(resolve => {
	if (document.readyState === 'interactive' || document.readyState === 'complete') {
		resolve();
	} else {
		document.addEventListener('DOMContentLoaded', () => {
			resolve();
		}, {
			capture: true,
			once: true,
			passive: true
		});
	}
});


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const mimicFn = __webpack_require__(32);

module.exports = (fn, options) => {
	if (typeof fn !== 'function') {
		throw new TypeError(`Expected the first argument to be a function, got \`${typeof fn}\``);
	}

	options = options || {};

	let timeout;
	let result;

	const debounced = function () {
		const context = this;
		const args = arguments;

		const later = () => {
			timeout = null;
			if (!options.immediate) {
				result = fn.apply(context, args);
			}
		};

		const callNow = options.immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, options.wait || 0);

		if (callNow) {
			result = fn.apply(context, args);
		}

		return result;
	};

	mimicFn(debounced, fn);

	debounced.cancel = () => {
		if (timeout) {
			clearTimeout(timeout);
			timeout = null;
		}
	};

	return debounced;
};


/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// CONCATENATED MODULE: ./src/libs/synchronous-storage.js
/**
 * Allows usage of async get/set API synchronously.
 * Requirements:
 * - SynchronousStorage must be the only way to get/set the storage
 * - The source API must be promised
 * - The first call must be awaited to make sure the value has been loaded
 *
 * Usage:

import SynchronousStorage from './synchronous-storage';

const storage = await new SynchronousStorage(
	() => browser.storage.local.get('name'),
	va => browser.storage.local.set({name: va})
);

console.log(storage.get()); // {}
storage.set('Federico');
console.log(storage.get()); // {name: 'Federico'}

 *
 * Caveats:
 * - .set() returns a promise that you can use to catch write errors.
 *   However if an error happens, SynchronousStorage will no longer match the real cache.
 */
class SynchronousStorage {
	constructor(get, set) {
		this._get = get;
		this._set = set;
		return get().then(value => {
			this._cache = value;
			return this;
		});
	}
	get() {
		return this._cache;
	}
	set(value) {
		this._cache = value;
		return this._set(value);
	}
}
// CONCATENATED MODULE: ./src/libs/icons.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_dom_chef__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_dom_chef___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_dom_chef__);


const check = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-hidden": "true", "class": "octicon octicon-check", height: "16", version: "1.1", viewBox: "0 0 12 16", width: "12" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5z" })
);

const mute = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-hidden": "true", "class": "octicon octicon-mute", height: "16", version: "1.1", viewBox: "0 0 16 16", width: "16" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M8 2.81v10.38c0 .67-.81 1-1.28.53L3 10H1c-.55 0-1-.45-1-1V7c0-.55.45-1 1-1h2l3.72-3.72C7.19 1.81 8 2.14 8 2.81zm7.53 3.22l-1.06-1.06-1.97 1.97-1.97-1.97-1.06 1.06L11.44 8 9.47 9.97l1.06 1.06 1.97-1.97 1.97 1.97 1.06-1.06L13.56 8l1.97-1.97z" })
);

const edit = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "class": "octicon octicon-pencil", height: "16", version: "1.1", viewBox: "0 0 14 16", width: "14" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M0 12v3h3l8-8-3-3L0 12z m3 2H1V12h1v1h1v1z m10.3-9.3l-1.3 1.3-3-3 1.3-1.3c0.39-0.39 1.02-0.39 1.41 0l1.59 1.59c0.39 0.39 0.39 1.02 0 1.41z" })
);

const openIssue = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-label": "issues", "class": "octicon octicon-issue-opened type-icon type-icon-state-open", height: "16", role: "img", version: "1.1", viewBox: "0 0 14 16", width: "14" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z" })
);

const closedIssue = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-label": "issues", "class": "octicon octicon-issue-closed type-icon type-icon-state-closed", height: "16", role: "img", version: "1.1", viewBox: "0 0 16 16", width: "16" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M7 10h2v2H7v-2zm2-6H7v5h2V4zm1.5 1.5l-1 1L12 9l4-4.5-1-1L12 7l-1.5-1.5zM8 13.7A5.71 5.71 0 0 1 2.3 8c0-3.14 2.56-5.7 5.7-5.7 1.83 0 3.45.88 4.5 2.2l.92-.92A6.947 6.947 0 0 0 8 1C4.14 1 1 4.14 1 8s3.14 7 7 7 7-3.14 7-7l-1.52 1.52c-.66 2.41-2.86 4.19-5.48 4.19v-.01z" })
);

const openPullRequest = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-label": "pull request", "class": "octicon octicon-git-pull-request type-icon type-icon-state-open", height: "16", role: "img", version: "1.1", viewBox: "0 0 12 16", width: "12" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z" })
);

const closedPullRequest = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-label": "pull request", "class": "octicon octicon-git-pull-request type-icon type-icon-state-closed", height: "16", role: "img", version: "1.1", viewBox: "0 0 12 16", width: "12" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z" })
);

const mergedPullRequest = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-label": "pull request", "class": "octicon octicon-git-pull-request type-icon type-icon-state-merged", height: "16", role: "img", version: "1.1", viewBox: "0 0 12 16", width: "12" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z" })
);

const tag = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "class": "octicon octicon-tag", height: "16", version: "1.1", viewBox: "0 0 14 16", width: "14" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M6.73 2.73c-0.47-0.47-1.11-0.73-1.77-0.73H2.5C1.13 2 0 3.13 0 4.5v2.47c0 0.66 0.27 1.3 0.73 1.77l6.06 6.06c0.39 0.39 1.02 0.39 1.41 0l4.59-4.59c0.39-0.39 0.39-1.02 0-1.41L6.73 2.73zM1.38 8.09c-0.31-0.3-0.47-0.7-0.47-1.13V4.5c0-0.88 0.72-1.59 1.59-1.59h2.47c0.42 0 0.83 0.16 1.13 0.47l6.14 6.13-4.73 4.73L1.38 8.09z m0.63-4.09h2v2H2V4z" })
);

const fork = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-hidden": "true", "class": "octicon octicon-repo-forked", height: "16", role: "img", version: "1.1", viewBox: "0 0 10 16", width: "10" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M8 1c-1.11 0-2 0.89-2 2 0 0.73 0.41 1.38 1 1.72v1.28L5 8 3 6v-1.28c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2S0 1.89 0 3c0 0.73 0.41 1.38 1 1.72v1.78l3 3v1.78c-0.59 0.34-1 0.98-1 1.72 0 1.11 0.89 2 2 2s2-0.89 2-2c0-0.73-0.41-1.38-1-1.72V9.5l3-3V4.72c0.59-0.34 1-0.98 1-1.72 0-1.11-0.89-2-2-2zM2 4.2c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3 10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z m3-10c-0.66 0-1.2-0.55-1.2-1.2s0.55-1.2 1.2-1.2 1.2 0.55 1.2 1.2-0.55 1.2-1.2 1.2z" })
);

const cloudUpload = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { "aria-hidden": "true", "class": "octicon octicon-cloud-upload", height: "16", role: "img", version: "1.1", viewBox: "0 0 16 16", width: "16" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { "fill-rule": "evenodd", d: "M7 9H5l3-3 3 3H9v5H7V9zm5-4c0-.44-.91-3-4.5-3C5.08 2 3 3.92 3 6 1.02 6 0 7.52 0 9c0 1.53 1 3 3 3h3v-1.3H3c-1.62 0-1.7-1.42-1.7-1.7 0-.17.05-1.7 1.7-1.7h1.3V6c0-1.39 1.56-2.7 3.2-2.7 2.55 0 3.13 1.55 3.2 1.8v1.2H12c.81 0 2.7.22 2.7 2.2 0 2.09-2.25 2.2-2.7 2.2h-2V12h2c2.08 0 4-1.16 4-3.5C16 6.06 14.08 5 12 5z" })
);

const darkCompare = Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
  "svg",
  { xmlns: "http://www.w3.org/2000/svg", "class": "octicon octicon-diff", height: "16", viewBox: "0 0 13 16", width: "13" },
  Object(__WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])("path", { d: "M6 7h2v1H6v2H5V8H3V7h2V5h1zm-3 6h5v-1H3zM7.5 2L11 5.5V15c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V3c0-.55.45-1 1-1zm1-2H3v1h5l4 4v8h1V4.5z", "fill-rule": "evenodd" })
);
// CONCATENATED MODULE: ./src/libs/page-detect.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_select_dom__);


const isGist = () => location.hostname.startsWith('gist.') || location.pathname.startsWith('gist/');

const isDashboard = () => location.pathname === '/' || /^(\/orgs\/[^/]+)?\/dashboard/.test(location.pathname);

const isRepo = () => !isGist() && /^\/[^/]+\/[^/]+/.test(location.pathname);

const getRepoPath = () => location.pathname.replace(/^\/[^/]+\/[^/]+/, '');

const getRepoURL = () => location.pathname.slice(1).split('/', 2).join('/');

const isRepoRoot = () => isRepo() && /^(\/?$|\/tree\/)/.test(getRepoPath()) && __WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.repository-meta-content');

const isRepoTree = () => isRepo() && /\/tree\//.test(getRepoPath());

const isIssueSearch = () => location.pathname.startsWith('/issues');

const isIssueList = () => isRepo() && /^\/issues\/?$/.test(getRepoPath());

const isIssue = () => isRepo() && /^\/issues\/\d+/.test(getRepoPath());

const isPRSearch = () => location.pathname.startsWith('/pulls');

const isPRList = () => isRepo() && /^\/pulls\/?$/.test(getRepoPath());

const isPR = () => isRepo() && /^\/pull\/\d+/.test(getRepoPath());

const isPRFiles = () => isRepo() && /^\/pull\/\d+\/files/.test(getRepoPath());

const isPRCommit = () => isRepo() && /^\/pull\/\d+\/commits\/[0-9a-f]{5,40}/.test(getRepoPath());

const isMilestoneList = () => isRepo() && /^\/milestones\/?$/.test(getRepoPath());

const isMilestone = () => isRepo() && /^\/milestone\/\d+/.test(getRepoPath());

const isLabelList = () => isRepo() && /^\/labels\/?(((?=\?).*)|$)/.test(getRepoPath());

const isLabel = () => isRepo() && /^\/labels\/\w+/.test(getRepoPath());

const isCommitList = () => isRepo() && /^\/commits\//.test(getRepoPath());

const isSingleCommit = () => isRepo() && /^\/commit\/[0-9a-f]{5,40}/.test(getRepoPath());

const isCommit = () => isSingleCommit() || isPRCommit() || isPRFiles() && __WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.full-commit');

const isCompare = () => isRepo() && /^\/compare/.test(getRepoPath());

const hasCode = () => isRepo() && __WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.highlight');

const hasDiff = () => isRepo() && (isSingleCommit() || isPRCommit() || isPRFiles() || isCompare() || isPR() && __WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.diff-table'));

const isReleases = () => isRepo() && /^\/(releases|tags)/.test(getRepoPath());

const isBlame = () => isRepo() && /^\/blame\//.test(getRepoPath());

const isNotifications = () => location.pathname.startsWith('/notifications');

const isRepoSettings = () => isRepo() && /^\/settings/.test(getRepoPath());

const getOwnerAndRepo = () => {
	const [, ownerName, repoName] = location.pathname.split('/');

	return {
		ownerName,
		repoName
	};
};

const isSingleFile = () => {
	const { ownerName, repoName } = getOwnerAndRepo();
	const blobPattern = new RegExp(`/${ownerName}/${repoName}/blob/`);
	return isRepo() && blobPattern.test(location.href);
};

const hasCommentForm = () => __WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.js-previewable-comment-form');
// CONCATENATED MODULE: ./src/libs/mark-unread.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_webextension_polyfill__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_webextension_polyfill___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_webextension_polyfill__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_github_injection__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_github_injection___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_github_injection__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_select_dom__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_select_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_dom_chef__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_dom_chef___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_dom_chef__);








let storage;

function stripHash(url) {
	return url.replace(/#.+$/, '');
}

function addMarkUnreadButton() {
	const container = __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.js-thread-subscription-status');
	if (container) {
		const button = Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
			'button',
			{ 'class': 'btn btn-sm btn-mark-unread js-mark-unread' },
			'Mark as unread'
		);
		button.addEventListener('click', markUnread, {
			once: true
		});
		container.append(button);
	}
}

function markRead(url) {
	const unreadNotifications = storage.get();
	unreadNotifications.forEach((notification, index) => {
		if (notification.url === url) {
			unreadNotifications.splice(index, 1);
		}
	});

	for (const a of __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.all(`a.js-notification-target[href="${url}"]`)) {
		const li = a.closest('li.js-notification');
		li.classList.remove('unread');
		li.classList.add('read');
	}

	storage.set(unreadNotifications);
}

function markUnread() {
	const participants = __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.all('.participant-avatar').map(el => ({
		username: el.getAttribute('aria-label'),
		avatar: el.querySelector('img').src
	}));

	const { ownerName, repoName } = getOwnerAndRepo();
	const repository = `${ownerName}/${repoName}`;
	const title = __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.js-issue-title').textContent.trim();
	const type = isPR() ? 'pull-request' : 'issue';
	const url = stripHash(location.href);

	const stateLabel = __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.gh-header-meta .State');
	let state;

	if (stateLabel.classList.contains('State--green')) {
		state = 'open';
	} else if (stateLabel.classList.contains('State--purple')) {
		state = 'merged';
	} else if (stateLabel.classList.contains('State--red')) {
		state = 'closed';
	}

	const lastCommentTime = __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.all('.timeline-comment-header relative-time').pop();
	const dateTitle = lastCommentTime.title;
	const date = lastCommentTime.getAttribute('datetime');

	const unreadNotifications = storage.get();

	unreadNotifications.push({
		participants,
		repository,
		title,
		state,
		type,
		dateTitle,
		date,
		url
	});

	storage.set(unreadNotifications);
	updateUnreadIndicator();

	this.setAttribute('disabled', 'disabled');
	this.textContent = 'Marked as unread';
}

function renderNotifications() {
	const unreadNotifications = storage.get().filter(notification => !isNotificationExist(notification.url)).filter(notification => {
		if (!isParticipatingPage()) {
			return true;
		}

		const { participants } = notification;
		const myUserName = getUserName();

		return participants.filter(participant => participant.username === myUserName).length > 0;
	});

	if (unreadNotifications.length === 0) {
		return;
	}

	if (isEmptyPage()) {
		__WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.blankslate').remove();
		__WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.js-navigation-container').append(Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])('div', { 'class': 'notifications-list' }));
	}

	unreadNotifications.forEach(notification => {
		const {
			participants,
			repository,
			title,
			state,
			type,
			dateTitle,
			date,
			url
		} = notification;

		let icon;

		if (type === 'issue') {
			if (state === 'open') {
				icon = openIssue;
			}

			if (state === 'closed') {
				icon = closedIssue;
			}
		}

		if (type === 'pull-request') {
			if (state === 'open') {
				icon = openPullRequest;
			}

			if (state === 'merged') {
				icon = mergedPullRequest;
			}

			if (state === 'closed') {
				icon = closedPullRequest;
			}
		}

		const hasList = __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.exists(`a.notifications-repo-link[title="${repository}"]`);
		if (!hasList) {
			const list = Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'div',
				{ 'class': 'boxed-group flush' },
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'form',
					{ 'class': 'boxed-group-action' },
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
						'button',
						{ 'class': 'mark-all-as-read css-truncate tooltipped tooltipped-w js-mark-all-read', 'aria-label': 'Mark all notifications as read' },
						check
					)
				),
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'h3',
					null,
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
						'a',
						{ href: '/' + repository, 'class': 'css-truncate css-truncate-target notifications-repo-link', title: repository },
						repository
					)
				),
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])('ul', { 'class': 'boxed-group-inner list-group notifications' })
			);

			$('.notifications-list').prepend(list);
		}

		const list = $(`a.notifications-repo-link[title="${repository}"]`).parent().siblings('ul.notifications');

		const usernames = participants.map(participant => participant.username).join(', ');

		const avatars = participants.map(participant => {
			return Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])('img', { alt: `@${participant.username}`, 'class': 'avatar from-avatar', src: participant.avatar, width: 39, height: 39 });
		});

		const item = Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
			'li',
			{ 'class': `list-group-item js-notification js-navigation-item unread ${type}-notification` },
			Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'span',
				{ 'class': 'list-group-item-name css-truncate' },
				icon,
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'a',
					{ href: url, 'class': 'css-truncate-target js-notification-target js-navigation-open list-group-item-link' },
					title
				)
			),
			Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'ul',
				{ 'class': 'notification-actions' },
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'li',
					{ 'class': 'delete' },
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
						'button',
						{ 'aria-label': 'Mark as read', 'class': 'btn-link delete-note tooltipped tooltipped-w js-mark-read' },
						check
					)
				),
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'li',
					{ 'class': 'mute' },
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
						'button',
						{ style: { opacity: 0, pointerEvents: 'none' } },
						mute
					)
				),
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'li',
					{ 'class': 'age' },
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])('relative-time', { datetime: date, title: dateTitle })
				),
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'li',
					{ 'class': 'tooltipped tooltipped-s', 'aria-label': usernames },
					Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
						'div',
						{ 'class': 'avatar-stack clearfix' },
						avatars
					)
				)
			)
		);

		list.prepend(item);
	});

	// Make sure that all the boxes with unread items are at the top
	// This is necessary in the "All notifications" view
	$('.boxed-group:has(".unread")').prependTo('.notifications-list');
}

function isNotificationExist(url) {
	return __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.exists(`a.js-notification-target[href^="${stripHash(url)}"]`);
}

function isEmptyPage() {
	return __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.exists('.blankslate');
}

function isParticipatingPage() {
	return (/\/notifications\/participating/.test(location.pathname)
	);
}

function getUserName() {
	return __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('#user-links a.name img').getAttribute('alt').slice(1);
}

function updateUnreadIndicator() {
	const icon = __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('.notification-indicator');
	if (!icon) {
		return;
	}
	const statusMark = icon.querySelector('.mail-status');
	const hasRealNotifications = icon.matches('[data-ga-click$=":unread"]');

	const hasUnread = hasRealNotifications || storage.get().length > 0;
	const label = hasUnread ? 'You have unread notifications' : 'You have no unread notifications';

	icon.setAttribute('aria-label', label);
	statusMark.classList.toggle('unread', hasUnread);
}

function markNotificationRead(e) {
	const notification = e.target.closest('li.js-notification');
	const a = notification.querySelector('a.js-notification-target');
	markRead(a.href);
	updateUnreadIndicator();
}

function markAllNotificationsRead(e) {
	e.preventDefault();
	const repoGroup = e.target.closest('.boxed-group');
	for (const a of repoGroup.querySelectorAll('a.js-notification-target')) {
		markRead(a.href);
	}
	updateUnreadIndicator();
}

function addCustomAllReadBtn() {
	const hasMarkAllReadBtnExists = __WEBPACK_IMPORTED_MODULE_2_select_dom___default.a.exists('#notification-center a[href="#mark_as_read_confirm_box"]');
	if (hasMarkAllReadBtnExists || storage.get().length === 0) {
		return;
	}

	$('#notification-center .tabnav-tabs:first').append(Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
		'div',
		{ 'class': 'float-right' },
		Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
			'a',
			{ href: '#mark_as_read_confirm_box', 'class': 'btn btn-sm', rel: 'facebox' },
			'Mark all as read'
		),
		Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
			'div',
			{ id: 'mark_as_read_confirm_box', style: { display: 'none' } },
			Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'h2',
				{ 'class': 'facebox-header', 'data-facebox-id': 'facebox-header' },
				'Are you sure?'
			),
			Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'p',
				{ 'data-facebox-id': 'facebox-description' },
				'Are you sure you want to mark all unread notifications as read?'
			),
			Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
				'div',
				{ 'class': 'full-button' },
				Object(__WEBPACK_IMPORTED_MODULE_3_dom_chef__["h"])(
					'button',
					{ id: 'clear-local-notification', 'class': 'btn btn-block' },
					'Mark all notifications as read'
				)
			)
		)
	));

	$(document).on('click', '#clear-local-notification', () => {
		storage.set([]);
		location.reload();
	});
}

function updateLocalNotificationsCount() {
	const unreadCount = __WEBPACK_IMPORTED_MODULE_2_select_dom___default()('#notification-center .filter-list a[href="/notifications"] .count');
	const githubNotificationsCount = Number(unreadCount.textContent);
	const localNotifications = storage.get();

	if (localNotifications) {
		unreadCount.textContent = githubNotificationsCount + localNotifications.length;
	}
}

// Migrate old localStorage.unreadNotifications to new storage.
// For extra safety, keep the old notifications under a different name.
// Drop function in mid August and drop the new key as well.
function migrateOldStorage() {
	const oldStorage = localStorage.getItem('unreadNotifications');
	if (oldStorage) {
		const list = JSON.parse(oldStorage);
		console.log('Migrating old unreadNotifications storage', list);
		storage.set(list);
		localStorage.setItem('_unreadNotifications_migrated', JSON.stringify(list));
		localStorage.removeItem('unreadNotifications');
	}
}

async function setup() {
	storage = await new SynchronousStorage(() => {
		return __WEBPACK_IMPORTED_MODULE_0_webextension_polyfill___default.a.storage.local.get({
			unreadNotifications: []
		}).then(storage => storage.unreadNotifications);
	}, unreadNotifications => {
		return __WEBPACK_IMPORTED_MODULE_0_webextension_polyfill___default.a.storage.local.set({ unreadNotifications });
	});
	migrateOldStorage();
	__WEBPACK_IMPORTED_MODULE_1_github_injection___default()(window, () => {
		destroy();

		if (isNotifications()) {
			renderNotifications();
			addCustomAllReadBtn();
			updateLocalNotificationsCount();
			$(document).on('click', '.js-mark-read', markNotificationRead);
			$(document).on('click', '.js-mark-all-read', markAllNotificationsRead);
			$(document).on('click', '.js-delete-notification button', updateUnreadIndicator);
			$(document).on('click', 'form[action="/notifications/mark"] button', () => {
				storage.set([]);
			});
		} else if (isPR() || isIssue()) {
			markRead(location.href);
			addMarkUnreadButton();
		}

		updateUnreadIndicator();
	});
}

function destroy() {
	$(document).off('click', '.js-mark-unread', markUnread);
	$('.js-mark-unread').remove();
}

/* harmony default export */ var mark_unread_defaultExport = ({
	setup,
	destroy
});
// CONCATENATED MODULE: ./src/libs/copy-gist.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_select_dom__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_select_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_dom_chef__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_dom_chef___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_dom_chef__);




/* harmony default export */ var copy_gist_defaultExport = (() => {
	// Button already added (partial page nav), or non-text file
	if (__WEBPACK_IMPORTED_MODULE_1_select_dom___default.a.exists('.copy-btn')) {
		return;
	}

	$('.blob-wrapper').each((i, blob) => {
		const actionsParent = blob.parentNode.querySelector('.file-actions');
		const $btn = $(Object(__WEBPACK_IMPORTED_MODULE_2_dom_chef__["h"])(
			'button',
			{ 'class': 'btn btn-sm copy-btn gist-copy-btn' },
			'Copy'
		));
		$btn.data('blob', blob);
		$btn.prependTo(actionsParent);
	});

	$(document).on('click', '.copy-btn', e => {
		e.preventDefault();
		const fileContents = $(e.currentTarget).data('blob').innerText;
		__WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default()(fileContents);
	});
});
// CONCATENATED MODULE: ./src/libs/upload-button.js
/* harmony import */ var upload_button___WEBPACK_IMPORTED_MODULE_0_dom_chef__ = __webpack_require__(1);
/* harmony import */ var upload_button___WEBPACK_IMPORTED_MODULE_0_dom_chef___default = __webpack_require__.n(upload_button___WEBPACK_IMPORTED_MODULE_0_dom_chef__);




const isMac = /Mac/.test(window.navigator.platform);

/* harmony default export */ var upload_button_defaultExport = (() => {
	if (hasCommentForm()) {
		$('.js-previewable-comment-form').each((index, element) => {
			const $element = $(element);
			if (!$element.hasClass('refined-github-has-upload-btn')) {
				const uploadBtn = Object(upload_button___WEBPACK_IMPORTED_MODULE_0_dom_chef__["h"])(
					'label',
					{ 'for': `refined-github-upload-btn-${index}`, 'class': 'toolbar-item tooltipped tooltipped-nw refined-github-upload-btn', 'aria-label': 'Upload a file' },
					cloudUpload
				);

				$('.comment-form-head .toolbar-commenting .toolbar-group:last-child', element).append(uploadBtn);

				const keydownHandler = event => {
					if (event.which === 85 && (isMac ? event.metaKey : event.ctrlKey)) {
						event.preventDefault();
						uploadBtn.click();
					}
				};
				$element.find('.js-comment-field').focus(() => $(document).on('keydown', keydownHandler)).blur(() => $(document).off('keydown', keydownHandler));

				$element.find('.js-write-bucket .drag-and-drop .default .js-manual-file-chooser').attr('id', `refined-github-upload-btn-${index}`);
				$element.addClass('refined-github-has-upload-btn');
			}
		});
	}
});
// CONCATENATED MODULE: ./src/libs/copy-on-y.js
/* harmony import */ var copy_on_y___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__ = __webpack_require__(5);
/* harmony import */ var copy_on_y___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default = __webpack_require__.n(copy_on_y___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__);
/* harmony import */ var copy_on_y___WEBPACK_IMPORTED_MODULE_1_select_dom__ = __webpack_require__(0);
/* harmony import */ var copy_on_y___WEBPACK_IMPORTED_MODULE_1_select_dom___default = __webpack_require__.n(copy_on_y___WEBPACK_IMPORTED_MODULE_1_select_dom__);



const Y_KEYCODE = 89;

const handler = ({ keyCode, target }) => {
	if (keyCode === Y_KEYCODE && target.nodeName !== 'INPUT') {
		const commitIsh = copy_on_y___WEBPACK_IMPORTED_MODULE_1_select_dom___default()('.commit-tease-sha').textContent.trim();
		const uri = location.href.replace(/\/blob\/[\w-]+\//, `/blob/${commitIsh}/`);

		copy_on_y___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default()(uri);
	}
};

const copy_on_y_setup = () => {
	window.addEventListener('keyup', handler);
};

const copy_on_y_destroy = () => {
	window.removeEventListener('keyup', handler);
};

/* harmony default export */ var copy_on_y_defaultExport = ({
	setup: copy_on_y_setup,
	destroy: copy_on_y_destroy
});
// CONCATENATED MODULE: ./src/libs/utils.js
/* harmony import */ var utils___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var utils___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(utils___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_element_ready__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_element_ready___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_element_ready__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_dom_loaded__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_dom_loaded___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_dom_loaded__);




const getUsername = () => utils___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('meta[name="user-login"]').getAttribute('content');

const groupBy = (array, grouper) => array.reduce((map, item) => {
	const key = grouper(item);
	map[key] = map[key] || [];
	map[key].push(item);
	return map;
}, {});

const emptyElement = element => {
	// https://stackoverflow.com/a/3955238/288906
	while (element.firstChild) {
		element.firstChild.remove();
	}
};

/**
 * Automatically stops checking for an element to appear once the DOM is ready.
 */
const safeElementReady = selector => {
	const waiting = __WEBPACK_IMPORTED_MODULE_1_element_ready___default()(selector);
	__WEBPACK_IMPORTED_MODULE_2_dom_loaded___default.a.then(() => requestAnimationFrame(() => waiting.cancel()));
	return waiting;
};

const observeEl = (el, listener, options = { childList: true }) => {
	if (typeof el === 'string') {
		el = utils___WEBPACK_IMPORTED_MODULE_0_select_dom___default()(el);
	}

	// Run first
	listener([]);

	// Run on updates
	return new MutationObserver(listener).observe(el, options);
};

// Concats arrays but does so like a zipper instead of appending them
// [[0, 1, 2], [0, 1]] => [0, 0, 1, 1, 2]
// Like lodash.zip
const flatZip = (table, limit = Infinity) => {
	const maxColumns = Math.max(...table.map(row => row.length));
	const zipped = [];
	for (let col = 0; col < maxColumns; col++) {
		for (const row of table) {
			if (row[col]) {
				zipped.push(row[col]);
				if (limit !== Infinity && zipped.length === limit) {
					return zipped;
				}
			}
		}
	}
	return zipped;
};
// CONCATENATED MODULE: ./src/libs/reactions-avatars.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_debounce_fn__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_debounce_fn___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_debounce_fn__);
/* harmony import */ var reactions_avatars___WEBPACK_IMPORTED_MODULE_1_select_dom__ = __webpack_require__(0);
/* harmony import */ var reactions_avatars___WEBPACK_IMPORTED_MODULE_1_select_dom___default = __webpack_require__.n(reactions_avatars___WEBPACK_IMPORTED_MODULE_1_select_dom__);
/* harmony import */ var reactions_avatars___WEBPACK_IMPORTED_MODULE_2_dom_chef__ = __webpack_require__(1);
/* harmony import */ var reactions_avatars___WEBPACK_IMPORTED_MODULE_2_dom_chef___default = __webpack_require__.n(reactions_avatars___WEBPACK_IMPORTED_MODULE_2_dom_chef__);





const arbitraryAvatarLimit = 36;
const approximateHeaderLength = 3; // Each button header takes about as much as 3 avatars

function getParticipants(container) {
	const currentUser = getUsername();
	return container.getAttribute('aria-label').replace(/ reacted with.*/, '').replace(/,? and /, ', ').replace(/, \d+ more/, '').split(', ').filter(username => username !== currentUser).map(username => ({
		container,
		username
	}));
}

function add() {
	for (const list of reactions_avatars___WEBPACK_IMPORTED_MODULE_1_select_dom___default.a.all(`.has-reactions .comment-reactions-options:not(.rgh-reactions)`)) {
		const avatarLimit = arbitraryAvatarLimit - list.children.length * approximateHeaderLength;

		const participantByReaction = [].map.call(list.children, getParticipants);
		const flatParticipants = flatZip(participantByReaction, avatarLimit);

		for (const participant of flatParticipants) {
			participant.container.append(Object(reactions_avatars___WEBPACK_IMPORTED_MODULE_2_dom_chef__["h"])(
				'a',
				{ href: `/${participant.username}` },
				Object(reactions_avatars___WEBPACK_IMPORTED_MODULE_2_dom_chef__["h"])('img', { src: `/${participant.username}.png?size=${window.devicePixelRatio * 20}` })
			));
		}

		list.classList.add('rgh-reactions');

		// Overlap reaction avatars when near the avatarLimit
		if (flatParticipants.length > avatarLimit * 0.9) {
			list.classList.add('rgh-reactions-near-limit');
		}
	}
}

// Feature testable on
// https://github.com/babel/babel/pull/3646
/* harmony default export */ var reactions_avatars_defaultExport = (() => {
	add();
	document.addEventListener('socket:message', __WEBPACK_IMPORTED_MODULE_0_debounce_fn___default()(add, { wait: 100 }));
});
// CONCATENATED MODULE: ./src/libs/domify.js
/* harmony default export */ var domify_defaultExport = (html => {
	const template = document.createElement('template');
	template.innerHTML = html;
	return template.content;
});
// CONCATENATED MODULE: ./src/libs/show-names.js
/* harmony import */ var show_names___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var show_names___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(show_names___WEBPACK_IMPORTED_MODULE_0_select_dom__);




const storageKey = 'cachedNames';

const getCachedUsers = () => {
	return new Promise(resolve => chrome.storage.local.get(storageKey, resolve));
};

const fetchName = async username => {
	// /following/you_know is the lightest page we know
	// location.origin is required for Firefox #490
	const pageHTML = await fetch(`${location.origin}/${username}/following`).then(res => res.text());

	const el = domify_defaultExport(pageHTML).querySelector('h1 strong');

	// The full name might not be set
	const fullname = el && el.textContent.slice(1, -1);
	if (!fullname || fullname === username) {
		// It has to be stored as false or else it will be fetched every time
		return false;
	}
	return fullname;
};

/* harmony default export */ var show_names_defaultExport = (async () => {
	const myUsername = getUsername();
	const cache = (await getCachedUsers())[storageKey] || {};

	// {sindresorhus: [a.author, a.author], otheruser: [a.author]}
	const selector = `.js-discussion .author:not(.refined-github-fullname)`;
	const usersOnPage = groupBy(show_names___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all(selector), el => el.textContent);

	const fetchAndAdd = async username => {
		if (typeof cache[username] === 'undefined' && username !== myUsername) {
			cache[username] = await fetchName(username);
		}

		for (const usernameEl of usersOnPage[username]) {
			const commentedNode = usernameEl.parentNode.nextSibling;
			if (commentedNode && commentedNode.textContent.includes('commented')) {
				commentedNode.remove();
			}

			usernameEl.classList.add('refined-github-fullname');

			if (cache[username] && username !== myUsername) {
				// If it's a regular comment author, add it outside <strong>
				// otherwise it's something like "User added some commits"
				const insertionPoint = usernameEl.parentNode.tagName === 'STRONG' ? usernameEl.parentNode : usernameEl;
				insertionPoint.insertAdjacentText('afterend', ` (${cache[username]}) `);
			}
		}
	};

	const fetches = Object.keys(usersOnPage).map(fetchAndAdd);

	// Wait for all the fetches to be done
	await Promise.all(fetches);

	chrome.storage.local.set({ [storageKey]: cache });
});
// CONCATENATED MODULE: ./src/libs/copy-file-path.js
/* harmony import */ var copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_dom_chef__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_dom_chef___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_dom_chef__);




function addFilePathCopyBtn() {
	for (const file of copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all('#files .file-header:not(.rgh-copy-file-path)')) {
		file.classList.add('rgh-copy-file-path', 'js-zeroclipboard-container');

		copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.file-info a', file).classList.add('js-zeroclipboard-target');

		const viewButton = copy_file_path___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('[aria-label^="View"]', file);
		viewButton.classList.add('BtnGroup-item');
		viewButton.replaceWith(Object(__WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
			'div',
			{ 'class': 'BtnGroup' },
			Object(__WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
				'button',
				{ 'aria-label': 'Copy file path to clipboard', 'class': 'js-zeroclipboard btn btn-sm BtnGroup-item tooltipped tooltipped-s', 'data-copied-hint': 'Copied!', type: 'button' },
				'Copy path'
			),
			viewButton
		));
	}
}

/* harmony default export */ var copy_file_path_defaultExport = (() => {
	observeEl('#files', addFilePathCopyBtn, { childList: true, subtree: true });
});
// CONCATENATED MODULE: ./src/libs/copy-file.js
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__ = __webpack_require__(5);
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default = __webpack_require__.n(copy_file___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard__);
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom__ = __webpack_require__(0);
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom___default = __webpack_require__.n(copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom__);
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_2_dom_chef__ = __webpack_require__(1);
/* harmony import */ var copy_file___WEBPACK_IMPORTED_MODULE_2_dom_chef___default = __webpack_require__.n(copy_file___WEBPACK_IMPORTED_MODULE_2_dom_chef__);




/* harmony default export */ var copy_file_defaultExport = (() => {
	// Button already added (partial page nav), or non-text file
	if (copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom___default.a.exists('.copy-btn') || !copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom___default.a.exists('[data-line-number="1"]')) {
		return;
	}

	const targetSibling = copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom___default()('#raw-url');
	const fileUri = targetSibling.getAttribute('href');
	targetSibling.insertAdjacentElement('beforeBegin', Object(copy_file___WEBPACK_IMPORTED_MODULE_2_dom_chef__["h"])(
		'a',
		{ href: fileUri, 'class': 'btn btn-sm BtnGroup-item copy-btn' },
		'Copy'
	));

	$(document).on('click', '.copy-btn', e => {
		e.preventDefault();
		const fileContents = copy_file___WEBPACK_IMPORTED_MODULE_1_select_dom___default()('.js-file-line-container').innerText;
		copy_file___WEBPACK_IMPORTED_MODULE_0_copy_text_to_clipboard___default()(fileContents);
	});
});
// CONCATENATED MODULE: ./src/libs/get-text-nodes.js
/* harmony default export */ var get_text_nodes_defaultExport = (el => {
	const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
	const next = () => {
		const value = walker.nextNode();
		return {
			value,
			done: !value
		};
	};
	walker[Symbol.iterator] = () => ({ next });
	return walker;
});
// CONCATENATED MODULE: ./src/libs/linkify-urls-in-code.js
/* harmony import */ var linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_linkify_urls__ = __webpack_require__(33);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_linkify_urls___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_linkify_urls__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_linkify_issues__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_linkify_issues___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_linkify_issues__);






const linkifiedURLClass = 'refined-github-linkified-code';
const {
	ownerName: linkify_urls_in_code_ownerName,
	repoName: linkify_urls_in_code_repoName
} = getOwnerAndRepo();

const linkify_urls_in_code_options = {
	user: linkify_urls_in_code_ownerName,
	repo: linkify_urls_in_code_repoName,
	type: 'dom',
	attrs: {
		target: '_blank'
	}
};

const editTextNodes = (fn, el) => {
	// Spread required because the elements will change and the TreeWalker will break
	for (const textNode of [...get_text_nodes_defaultExport(el)]) {
		if (fn === __WEBPACK_IMPORTED_MODULE_1_linkify_urls___default.a && textNode.textContent.length < 11) {
			// Shortest url: http://j.mp
			continue;
		}
		const linkified = fn(textNode.textContent, linkify_urls_in_code_options);
		if (linkified.children.length > 0) {
			// Children are <a>
			textNode.replaceWith(linkified);
		}
	}
};

/* harmony default export */ var linkify_urls_in_code_defaultExport = (() => {
	const wrappers = linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all(`.highlight:not(.${linkifiedURLClass})`);

	// Don't linkify any already linkified code
	if (wrappers.length === 0) {
		return;
	}

	// Linkify full URLs
	// `.blob-code-inner` in diffs
	// `pre` in GitHub comments
	for (const el of linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all('.blob-code-inner, pre', wrappers)) {
		editTextNodes(__WEBPACK_IMPORTED_MODULE_1_linkify_urls___default.a, el);
	}

	// Linkify issue refs in comments
	for (const el of linkify_urls_in_code___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all('span.pl-c', wrappers)) {
		editTextNodes(__WEBPACK_IMPORTED_MODULE_2_linkify_issues___default.a, el);
	}

	// Mark code block as touched
	for (const el of wrappers) {
		el.classList.add(linkifiedURLClass);
	}
});
// CONCATENATED MODULE: ./src/libs/auto-load-more-news.js
/* harmony import */ var auto_load_more_news___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var auto_load_more_news___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(auto_load_more_news___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_debounce_fn__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_debounce_fn___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_debounce_fn__);




let btn;
let newsfeedObserver;

const loadMore = __WEBPACK_IMPORTED_MODULE_1_debounce_fn___default()(() => {
	btn.click();

	// If GH hasn't loaded the JS, the click will not load anything.
	// We can detect if it worked by looking at the button's state,
	// and then trying again (auto-debounced)
	if (!btn.disabled) {
		loadMore();
	}
}, { wait: 200 });

// Delete after Firefox 55 goes stable
// Also update applications.gecko.strict_min_version to 55.0 in manifest.json
const IntersectionObserver = window.IntersectionObserver || class IntersectionObserverLocalfill {
	maybeLoadMore() {
		if (window.innerHeight > btn.getBoundingClientRect().top - 500) {
			loadMore();
		}
	}
	observe() {
		window.addEventListener('scroll', this.maybeLoadMore);
		window.addEventListener('resize', this.maybeLoadMore);
		this.maybeLoadMore();
	}
	disconnect() {
		window.removeEventListener('scroll', this.maybeLoadMore);
		window.removeEventListener('resize', this.maybeLoadMore);
	}
};

const inView = new IntersectionObserver(([{ isIntersecting }]) => {
	if (isIntersecting) {
		loadMore();
	}
}, {
	rootMargin: '500px' // https://github.com/sindresorhus/refined-github/pull/505#issuecomment-309273098
});

const findButton = () => {
	// If the old button is still there, leave
	if (btn && document.contains(btn)) {
		return;
	}

	// Forget the old button
	inView.disconnect();

	// Watch the new button, or stop everything
	btn = auto_load_more_news___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.ajax-pagination-btn');
	if (btn) {
		inView.observe(btn);
	} else {
		newsfeedObserver.disconnect();
	}
};

/* harmony default export */ var auto_load_more_news_defaultExport = (() => {
	const form = auto_load_more_news___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.ajax-pagination-form');
	if (form) {
		// If GH hasn't loaded the JS,
		// the fake click will submit the form without ajax.
		form.addEventListener('submit', e => e.preventDefault());
		newsfeedObserver = observeEl('#dashboard .news', findButton);
		findButton();
	}
});
// CONCATENATED MODULE: ./src/libs/op-labels.js
/* harmony import */ var op_labels___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var op_labels___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(op_labels___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var op_labels___WEBPACK_IMPORTED_MODULE_1_dom_chef__ = __webpack_require__(1);
/* harmony import */ var op_labels___WEBPACK_IMPORTED_MODULE_1_dom_chef___default = __webpack_require__.n(op_labels___WEBPACK_IMPORTED_MODULE_1_dom_chef__);





/* harmony default export */ var op_labels_defaultExport = (() => {
	let op;
	if (isPR()) {
		const titleRegex = /^(?:.+) by (\S+) · Pull Request #(\d+)/;
		[, op] = titleRegex.exec(document.title) || [];
	} else {
		op = op_labels___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.timeline-comment-header-text .author').textContent;
	}

	let newComments = $(`.js-comment:not(.refined-github-op)`).has(`strong .author[href="/${op}"]`).get();

	if (!isPRFiles()) {
		newComments = newComments.slice(1);
	}

	if (newComments.length === 0) {
		return;
	}

	const type = isPR() ? 'pull request' : 'issue';
	const tooltip = `${op === getUsername() ? 'You' : 'This user'} submitted this ${type}.`;

	const placeholders = op_labels___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.all(`
		.timeline-comment .timeline-comment-header-text,
		.review-comment .comment-body
	`, newComments);

	for (const placeholder of placeholders) {
		placeholder.insertAdjacentElement('beforeBegin', Object(op_labels___WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
			'span',
			{ 'class': 'timeline-comment-label tooltipped tooltipped-multiline tooltipped-s', 'aria-label': tooltip },
			'Original\xA0Poster'
		));
	}

	for (const el of newComments) {
		el.classList.add('refined-github-op');
	}
});
// CONCATENATED MODULE: ./src/libs/add-releases-tab.js
/* harmony import */ var add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom__ = __webpack_require__(0);
/* harmony import */ var add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default = __webpack_require__.n(add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom__);
/* harmony import */ var add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef__ = __webpack_require__(1);
/* harmony import */ var add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef___default = __webpack_require__.n(add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef__);





const repoUrl = getRepoURL();

function appendReleasesCount(count) {
	if (!count) {
		return;
	}

	add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.reponav-releases').append(Object(add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
		'span',
		{ 'class': 'Counter' },
		count
	));
}

function cacheReleasesCount() {
	const releasesCountCacheKey = `${repoUrl}-releases-count`;

	if (isRepoRoot()) {
		const releasesCount = add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.numbers-summary a[href$="/releases"] .num').textContent.trim();
		appendReleasesCount(releasesCount);
		chrome.storage.local.set({ [releasesCountCacheKey]: releasesCount });
	} else {
		chrome.storage.local.get(releasesCountCacheKey, items => {
			appendReleasesCount(items[releasesCountCacheKey]);
		});
	}
}

/* harmony default export */ var add_releases_tab_defaultExport = (() => {
	if (add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default.a.exists('.reponav-releases')) {
		return;
	}

	const releasesTab = Object(add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
		'a',
		{ href: `/${repoUrl}/releases`, 'class': 'reponav-item reponav-releases', 'data-hotkey': 'g r', 'data-selected-links': `repo_releases /${repoUrl}/releases` },
		tag,
		Object(add_releases_tab___WEBPACK_IMPORTED_MODULE_1_dom_chef__["h"])(
			'span',
			null,
			' Releases '
		)
	);

	add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.reponav-dropdown, [data-selected-links~="repo_settings"]').insertAdjacentElement('beforeBegin', releasesTab);

	cacheReleasesCount();

	if (isReleases()) {
		releasesTab.classList.add('js-selected-navigation-item', 'selected');
		add_releases_tab___WEBPACK_IMPORTED_MODULE_0_select_dom___default()('.reponav-item.selected').classList.remove('js-selected-navigation-item', 'selected');
	}
});
// CONCATENATED MODULE: ./src/content.js
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_webext_dynamic_content_scripts__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_webext_options_sync__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_webext_options_sync___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_webext_options_sync__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_element_ready__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_element_ready___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_element_ready__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_github_injection__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_github_injection___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_github_injection__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_shorten_repo_url__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_shorten_repo_url___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_shorten_repo_url__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_to_semver__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_to_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_to_semver__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_linkify_issues__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_linkify_issues___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_linkify_issues__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_select_dom__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7_select_dom___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7_select_dom__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_dom_loaded__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_dom_loaded___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_dom_loaded__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_dom_chef__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_dom_chef___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9_dom_chef__);



















// - import copyMarkdown from './libs/copy-markdown';









// Add globals for easier debugging
window.$ = $;
window.select = __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a;

const content_repoUrl = getRepoURL();

function linkifyBranchRefs() {
	let deletedBranch = false;
	const lastBranchAction = __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all(`
		.discussion-item-head_ref_deleted .head-ref,
		.discussion-item-head_ref_restored .head-ref
	`).pop();
	if (lastBranchAction && lastBranchAction.closest('.discussion-item-head_ref_deleted')) {
		deletedBranch = lastBranchAction.title;
	}

	for (const el of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('.commit-ref[title], .base-ref[title], .head-ref[title]')) {
		if (el.textContent === 'unknown repository') {
			continue;
		}

		if (el.title === deletedBranch) {
			el.title = 'Deleted: ' + el.title;
			el.style.textDecoration = 'line-through';
			continue;
		}

		const branchUrl = '/' + el.title.replace(':', '/tree/');
		$(el).closest('.commit-ref').wrap(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])('a', { href: branchUrl }));
	}
}

function addCompareLink() {
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.refined-github-compare-tab')) {
		return;
	}

	__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.reponav-dropdown .dropdown-menu').prepend(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'a',
		{ href: `/${content_repoUrl}/compare`, 'class': 'dropdown-item refined-github-compare-tab', 'data-skip-pjax': true },
		darkCompare,
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'span',
			{ itemprop: 'name' },
			' Compare'
		)
	));
}

function renameInsightsDropdown() {
	const dropdown = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.reponav-item.reponav-dropdown');
	if (dropdown) {
		dropdown.firstChild.textContent = 'More ';
	} else {
		// GHE doesn't have the Insights dropdown currently, so create a dropdown
		const moreDropdown = Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'div',
			{ 'class': 'reponav-dropdown js-menu-container' },
			Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
				'button',
				{ type: 'button', 'class': 'btn-link reponav-item reponav-dropdown js-menu-target ', 'data-no-toggle': '', 'aria-expanded': 'false', 'aria-haspopup': 'true' },
				'More ',
				Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
					'svg',
					{ 'aria-hidden': 'true', 'class': 'octicon octicon-triangle-down v-align-middle text-y', height: '11', version: '1.1', viewBox: '0 0 12 16', width: '8' },
					Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])('path', { 'fill-rule': 'evenodd', d: 'M0 5l6 6 6-6z' })
				)
			),
			Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
				'div',
				{ 'class': 'dropdown-menu-content js-menu-content' },
				Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])('div', { 'class': 'dropdown-menu dropdown-menu-sw' })
			)
		);

		const settingsTab = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('[data-selected-links~="repo_settings"]');
		if (settingsTab) {
			settingsTab.parentNode.insertBefore(moreDropdown, settingsTab);
		} else {
			__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.reponav').appendChild(moreDropdown);
		}
	}
}

function hideEmptyMeta() {
	if (isRepoRoot()) {
		const meta = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.repository-meta');
		if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('em', meta) && !__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.js-edit-repo-meta-button')) {
			meta.style.display = 'none';
		}
	}
}

function moveMarketplaceLinkToProfileDropdown() {
	const thirdDropdownItem = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.dropdown-item[href="/explore"]');
	const marketplaceLink = Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'a',
		{ 'class': 'dropdown-item', href: '/marketplace' },
		'Marketplace'
	);
	thirdDropdownItem.insertAdjacentElement('afterend', marketplaceLink);
}

async function addTrendingMenuItem() {
	const secondListItem = await __WEBPACK_IMPORTED_MODULE_2_element_ready___default()('.header[role="banner"] ul[role="navigation"] li:nth-child(3)');
	secondListItem.insertAdjacentElement('afterEnd', Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'li',
		null,
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{ href: '/trending', 'class': 'js-selected-navigation-item header-navlink', 'data-selected-links': '/trending', 'data-hotkey': 'g t' },
			'Trending'
		)
	));
}

function addYoursMenuItem() {
	const pageName = isIssueSearch() ? 'issues' : 'pulls';
	const username = getUsername();

	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.refined-github-yours')) {
		return;
	}

	const yoursMenuItem = Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'a',
		{ href: `/${pageName}?q=is%3Aopen+is%3Aissue+user%3A${username}`, 'class': 'subnav-item refined-github-yours' },
		'Yours'
	);

	if (!__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.subnav-links .selected') && location.search.includes(`user%3A${username}`)) {
		yoursMenuItem.classList.add('selected');
		for (const tab of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all(`.subnav-links a[href*="user%3A${username}"]`)) {
			tab.href = tab.href.replace(`user%3A${username}`, '');
		}
	}

	__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.subnav-links').append(yoursMenuItem);
}

function addReadmeButtons() {
	const readmeContainer = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.repository-content > #readme');
	if (!readmeContainer) {
		return;
	}

	const buttons = Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])('div', { id: 'refined-github-readme-buttons' });

	/**
  * Generate Release button
  */
	const tags = __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('.branch-select-menu [data-tab-filter="tags"] .select-menu-item').map(element => [element.getAttribute('data-name'), element.getAttribute('href')]);
	const releases = new Map(tags);
	const [latestRelease] = __WEBPACK_IMPORTED_MODULE_5_to_semver___default()([...releases.keys()], { clean: false });
	if (latestRelease) {
		buttons.appendChild(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{
				'class': 'tooltipped tooltipped-nw',
				href: `${releases.get(latestRelease)}#readme`,
				'aria-label': `View this file at the latest version (${latestRelease})` },
			tag
		));
	}

	/**
  * Generate Edit button
  */
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.branch-select-menu i').textContent === 'Branch:') {
		const readmeName = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('#readme > h3').textContent.trim();
		const path = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.breadcrumb').textContent.trim().split('/').slice(1).join('/');
		const currentBranch = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.branch-select-menu .select-menu-item.selected').textContent.trim();
		buttons.appendChild(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{
				href: `/${content_repoUrl}/edit/${currentBranch}/${path}${readmeName}`,
				'class': 'tooltipped tooltipped-nw',
				'aria-label': 'Edit this file' },
			edit
		));
	}

	readmeContainer.appendChild(buttons);
}

function addDeleteForkLink() {
	const postMergeDescription = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('#partial-pull-merging .merge-branch-description');

	if (postMergeDescription) {
		const currentBranch = postMergeDescription.querySelector('.commit-ref.current-branch');
		const forkPath = currentBranch ? currentBranch.title.split(':')[0] : null;

		if (forkPath && forkPath !== content_repoUrl) {
			postMergeDescription.append(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
				'p',
				{ id: 'refined-github-delete-fork-link' },
				Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
					'a',
					{ href: `/${forkPath}/settings` },
					fork,
					'Delete fork'
				)
			));
		}
	}
}

function linkifyIssuesInTitles() {
	const isRed = !!location.href.match(/github\.com\/Redisrupt/);

	observeEl(__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('#partial-discussion-header').parentNode, () => {
		const title = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.js-issue-title:not(.refined-linkified-title)');
		if (title) {
			title.classList.add('refined-linkified-title');

			let text = title.textContent;
			if (isRed && /(CPM[- ]\d*)/.test(text) && !title.classList.contains('linkedText')) {
				title.classList.add('linkedText');
				text = text.replace(/(CPM[- ]\d*)/g, `<a target="blank" href="https://redisrupt.atlassian.net/browse/$1">$1</a>`);
				title.innerHTML = text;
			}

			editTextNodes(__WEBPACK_IMPORTED_MODULE_6_linkify_issues___default.a, title);
		}
	});
}

function addPatchDiffLinks() {
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.sha-block.patch-diff-links')) {
		return;
	}

	let commitUrl = location.pathname.replace(/\/$/, '');

	if (isPRCommit()) {
		commitUrl = commitUrl.replace(/\/pull\/\d+\/commits/, '/commit');
	}

	__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.commit-meta span.float-right').append(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'span',
		{ 'class': 'sha-block patch-diff-links' },
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{ href: `${commitUrl}.patch`, 'class': 'sha' },
			'patch'
		),
		' ' /* Workaround for: JSX eats whitespace between elements */,
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{ href: `${commitUrl}.diff`, 'class': 'sha' },
			'diff'
		)
	));
}

function removeSelectableWhiteSpaceFromDiffs() {
	for (const commentBtn of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('.add-line-comment')) {
		for (const node of commentBtn.childNodes) {
			if (node.nodeType === Node.TEXT_NODE) {
				node.remove();
			}
		}
	}
}

/* Lasciate ogne speranza, voi ch'intrate. */
function removeDiffSigns() {
	for (const line of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('tr:not(.refined-github-diff-signs)')) {
		line.classList.add('refined-github-diff-signs');
		for (const code of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('.blob-code-inner', line)) {
			// Drop -, + or space
			code.firstChild.textContent = code.firstChild.textContent.slice(1);

			// If a line is empty, the next line will collapse
			if (code.textContent.length === 0) {
				code.prepend(new Text(' '));
			}
		}
	}
}

function removeDiffSignsAndWatchExpansions() {
	removeSelectableWhiteSpaceFromDiffs();
	removeDiffSigns();
	for (const file of $('.diff-table:not(.rgh-watching-lines)').has('.diff-expander')) {
		file.classList.add('rgh-watching-lines');
		observeEl(file.tBodies[0], removeDiffSigns);
	}
}

function markMergeCommitsInList() {
	for (const commit of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('.commits-list-item:not(.refined-github-merge-commit)')) {
		if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('[title^="Merge pull request"]', commit)) {
			commit.classList.add('refined-github-merge-commit');
			commit.querySelector('.commit-avatar-cell').prepend(mergedPullRequest.cloneNode(true));
			commit.querySelector('.avatar').classList.add('avatar-child');
		}
	}
}

function indentInput(el, size = 4) {
	const selection = window.getSelection().toString();
	const { selectionStart, selectionEnd, value } = el;
	const isMultiLine = /\n/.test(selection);
	const firstLineStart = value.lastIndexOf('\n', selectionStart) + 1;

	el.focus();

	if (isMultiLine) {
		const selectedLines = value.substring(firstLineStart, selectionEnd);

		// Find the start index of each line
		const indexes = selectedLines.split('\n').map(line => line.length);
		indexes.unshift(firstLineStart);
		indexes.pop();

		// `indexes` contains lengths. Update them to point to each line start index
		for (let i = 1; i < indexes.length; i++) {
			indexes[i] += indexes[i - 1] + 1;
		}

		for (let i = indexes.length - 1; i >= 0; i--) {
			el.setSelectionRange(indexes[i], indexes[i]);
			document.execCommand('insertText', false, ' '.repeat(size));
		}

		// Restore selection position
		el.setSelectionRange(selectionStart + size, selectionEnd + size * indexes.length);
	} else {
		const indentSize = size - (selectionEnd - firstLineStart) % size || size;
		document.execCommand('insertText', false, ' '.repeat(indentSize));
	}
}

async function showRecentlyPushedBranches() {
	// Don't duplicate on back/forward in history
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('[data-url$=recently_touched_branches_list]')) {
		return;
	}

	const codeTabURL = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('[data-hotkey="g c"]').href;
	const fragmentURL = `/${content_repoUrl}/show_partial?partial=tree%2Frecently_touched_branches_list`;

	const html = await fetch(codeTabURL, {
		credentials: 'include'
	}).then(res => res.text());

	// https://github.com/sindresorhus/refined-github/issues/216
	if (html.includes(fragmentURL)) {
		__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.repository-content').prepend(Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])('include-fragment', { src: fragmentURL }));
	}
}

// Add option for viewing diffs without whitespace changes
function addDiffViewWithoutWhitespaceOption() {
	const container = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()(['.table-of-contents.Details .BtnGroup', // In single commit view
	'.pr-review-tools > .diffbar-item' // In review view
	].join(','));

	if (!container || __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.refined-github-toggle-whitespace')) {
		return;
	}

	const url = new URL(location.href);
	const hidingWhitespace = url.searchParams.get('w') === '1';

	if (hidingWhitespace) {
		url.searchParams.delete('w');
	} else {
		url.searchParams.set('w', 1);
	}

	container.insertAdjacentElement('afterend', Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'div',
		{ 'class': 'diffbar-item refined-github-toggle-whitespace' },
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{ href: url,
				'data-hotkey': 'd w',
				'class': `btn btn-sm btn-outline BtnGroup-item tooltipped tooltipped-s ${hidingWhitespace ? 'bg-gray-light text-gray-light' : ''}`,
				'aria-label': `${hidingWhitespace ? 'Show' : 'Hide'} whitespace in diffs` },
			hidingWhitespace ? check : '',
			' ',
			'No Whitespace'
		)
	));
}

function addMilestoneNavigation() {
	__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.repository-content').insertAdjacentElement('beforeBegin', Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'div',
		{ 'class': 'subnav' },
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'div',
			{ 'class': 'subnav-links float-left', role: 'navigation' },
			Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
				'a',
				{ href: `/${content_repoUrl}/labels`, 'class': 'subnav-item' },
				'Labels'
			),
			Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
				'a',
				{ href: `/${content_repoUrl}/milestones`, 'class': 'subnav-item' },
				'Milestones'
			)
		)
	));
}

function addFilterCommentsByYou() {
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('.refined-github-filter')) {
		return;
	}
	__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.subnav-search-context .js-navigation-item:last-child').insertAdjacentElement('beforeBegin', Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
		'a',
		{
			href: `/${content_repoUrl}/issues?q=is%3Aopen+commenter:${getUsername()}`,
			'class': 'select-menu-item js-navigation-item refined-github-filter' },
		Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'div',
			{ 'class': 'select-menu-item-text' },
			'Everything commented by you'
		)
	));
}

function addProjectNewLink() {
	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('#projects-feature:checked') && !__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('#refined-github-project-new-link')) {
		__WEBPACK_IMPORTED_MODULE_7_select_dom___default()(`#projects-feature ~ p.note`).insertAdjacentElement('afterEnd', Object(__WEBPACK_IMPORTED_MODULE_9_dom_chef__["h"])(
			'a',
			{ href: `/${content_repoUrl}/projects/new`, 'class': 'btn btn-sm', id: 'refined-github-project-new-link' },
			'Add a project'
		));
	}
}

function removeProjectsTab() {
	const projectsTab = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.js-repo-nav .reponav-item[data-selected-links^="repo_projects"]');
	if (projectsTab && projectsTab.querySelector('.Counter, .counter').textContent === '0') {
		projectsTab.remove();
	}
}

function fixSquashAndMergeTitle() {
	const btn = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.merge-message .btn-group-squash [type=submit]');
	if (!btn) {
		return;
	}
	btn.addEventListener('click', () => {
		const title = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.js-issue-title').textContent;
		const number = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.gh-header-number').textContent;
		__WEBPACK_IMPORTED_MODULE_7_select_dom___default()('#merge_title_field').value = `${title.trim()} (${number})`;
	});
}

function addTitleToEmojis() {
	for (const emoji of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('g-emoji')) {
		emoji.setAttribute('title', `:${emoji.getAttribute('alias')}:`);
	}
}

function sortMilestonesByClosestDueDate() {
	for (const a of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('a[href$="/milestones"], a[href*="/milestones?"]')) {
		const url = new URL(a.href);
		// Only if they aren't explicitly sorted differently
		if (!url.searchParams.get('direction') && !url.searchParams.get('sort')) {
			url.searchParams.set('direction', 'asc');
			url.searchParams.set('sort', 'due_date');
			a.href = url;
		}
	}
}

function moveAccountSwitcherToSidebar() {
	safeElementReady('.dashboard-sidebar').then(sidebar => {
		const switcher = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.account-switcher');
		if (switcher) {
			sidebar.prepend(switcher);
		}
	});
}

function init() {
	//
	// const username = getUsername();
	// if (!username) {
	// 	return;
	// }

	if (__WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.exists('html.refined-github')) {
		console.count('Refined GitHub was loaded multiple times: https://github.com/sindresorhus/refined-github/issues/479');
		return;
	}

	document.documentElement.classList.add('refined-github');

	if (!isGist()) {
		addTrendingMenuItem();
	}

	if (isDashboard()) {
		moveAccountSwitcherToSidebar();
	}

	// Support indent with tab key in comments
	$(document).on('keydown', '.js-comment-field', event => {
		if (event.which === 9 && !event.shiftKey) {
			// Don't indent if the suggester box is active
			if ($('.suggester').hasClass('active')) {
				return;
			}

			event.preventDefault();
			indentInput(event.target);
			return false;
		}
	});

	// Prompt user to confirm erasing a comment with the Cancel button
	$(document).on('click', '.js-hide-inline-comment-form', event => {
		// Do not prompt if textarea is empty
		const textarea = event.target.closest('.js-inline-comment-form').querySelector('.js-comment-field');
		if (textarea.value === '') {
			return;
		}

		if (window.confirm('Are you sure you want to discard your unsaved changes?') === false) {
			// eslint-disable-line no-alert
			event.stopPropagation();
			event.stopImmediatePropagation();
		}
	});

	// Handle issue list ajax
	$(document).on('pjax:end', () => {
		if (isIssueSearch() || isPRSearch()) {
			addYoursMenuItem();
		}
	});

	// TODO: Enable this when we've improved how copying Markdown works
	// See #522
	// $(document).on('copy', '.markdown-body', copyMarkdown);

	onDomReady();
}

async function onDomReady() {
	const options = await new __WEBPACK_IMPORTED_MODULE_1_webext_options_sync___default.a().getAll();
	await __WEBPACK_IMPORTED_MODULE_8_dom_loaded___default.a;

	const username = getUsername();

	mark_unread_defaultExport.setup();

	if (!isGist()) {
		moveMarketplaceLinkToProfileDropdown();
	}

	if (isGist()) {
		copy_gist_defaultExport();
	}

	if (isDashboard()) {
		// Hide other users starring/forking your repos
		if (options.hideStarsOwnRepos) {
			observeEl('#dashboard .news', () => {
				$('#dashboard .news .watch_started, #dashboard .news .fork').has(`.title a[href^="/${username}"]`).css('display', 'none');
			});
		}

		auto_load_more_news_defaultExport();
	}

	observeEl('div[role=main]', upload_button_defaultExport, { childList: true, subtree: true });

	if (isIssueSearch() || isPRSearch()) {
		addYoursMenuItem();
	}

	if (isRepo()) {
		__WEBPACK_IMPORTED_MODULE_3_github_injection___default()(window, () => {
			hideEmptyMeta();
			renameInsightsDropdown();
			add_releases_tab_defaultExport();
			removeProjectsTab();
			addCompareLink();
			addTitleToEmojis();
			addReadmeButtons();

			for (const a of __WEBPACK_IMPORTED_MODULE_7_select_dom___default.a.all('a[href]')) {
				Object(__WEBPACK_IMPORTED_MODULE_4_shorten_repo_url__["applyToLink"])(a, location.href);
			}

			copy_on_y_defaultExport.destroy();

			if (isPR()) {
				linkifyBranchRefs();
				addDeleteForkLink();
				fixSquashAndMergeTitle();
			}

			if (isPR() || isIssue()) {
				linkifyIssuesInTitles();
				observeEl('.new-discussion-timeline', op_labels_defaultExport, { childList: true, subtree: true });
			}

			if (isPRList() || isIssueList()) {
				addFilterCommentsByYou();
				showRecentlyPushedBranches();
			}

			if (isCommit()) {
				addPatchDiffLinks();
			}

			if (hasDiff()) {
				const diffElements = __WEBPACK_IMPORTED_MODULE_7_select_dom___default()('.js-discussion, #files');
				if (diffElements) {
					observeEl(diffElements, removeDiffSignsAndWatchExpansions, { childList: true, subtree: true });
				}
				addDiffViewWithoutWhitespaceOption();
			}

			if (isPR() || isIssue() || isCommit()) {
				reactions_avatars_defaultExport();
				show_names_defaultExport();
			}

			if (isCommitList()) {
				markMergeCommitsInList();
			}

			if (isPRFiles() || isPRCommit()) {
				copy_file_path_defaultExport();
			}

			if (isSingleFile()) {
				copy_file_defaultExport();
				copy_on_y_defaultExport.setup();
			}

			if (isMilestone()) {
				addMilestoneNavigation();
			}

			if (hasCode()) {
				linkify_urls_in_code_defaultExport();
			}

			if (isRepoSettings()) {
				addProjectNewLink();
			}

			sortMilestonesByClosestDueDate(); // Needs to be after addMilestoneNavigation
		});
	}
}

init();

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


class CancelError extends Error {
	constructor() {
		super('Promise was canceled');
		this.name = 'CancelError';
	}
}

class PCancelable extends Promise {
	static fn(fn) {
		return function () {
			const args = [].slice.apply(arguments);
			return new PCancelable((onCancel, resolve, reject) => {
				args.unshift(onCancel);
				fn.apply(null, args).then(resolve, reject);
			});
		};
	}

	constructor(executor) {
		super(resolve => {
			resolve();
		});

		this._pending = true;
		this._canceled = false;

		this._promise = new Promise((resolve, reject) => {
			this._reject = reject;

			return executor(
				fn => {
					this._cancel = fn;
				},
				val => {
					this._pending = false;
					resolve(val);
				},
				err => {
					this._pending = false;
					reject(err);
				}
			);
		});
	}

	then() {
		return this._promise.then.apply(this._promise, arguments);
	}

	catch() {
		return this._promise.catch.apply(this._promise, arguments);
	}

	cancel() {
		if (!this._pending || this._canceled) {
			return;
		}

		if (typeof this._cancel === 'function') {
			try {
				this._cancel();
			} catch (err) {
				this._reject(err);
			}
		}

		this._canceled = true;
		this._reject(new CancelError());
	}

	get canceled() {
		return this._canceled;
	}
}

module.exports = PCancelable;
module.exports.CancelError = CancelError;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

const {URL} = __webpack_require__(15);
const reservedPaths = __webpack_require__(16);

const patchDiffRegex = /[.](patch|diff)$/;
const releaseRegex = /releases[/]tag[/]([^/]+)/;
const labelRegex = /labels[/]([^/]+)/;
const releaseArchiveRegex = /archive[/](.+)([.]zip|[.]tar[.]gz)/;
const releaseDownloadRegex = /releases[/]download[/]([^/]+)[/](.+)/;

function styleRevision(revision) {
	if (!revision) {
		return;
	}
	revision = revision.replace(patchDiffRegex, '');
	if (/^[0-9a-f]{40}$/.test(revision)) {
		revision = revision.substr(0, 7);
	}
	return `<code>${revision}</code>`;
}

// Filter out null values
function joinValues(array, delimiter = '/') {
	return array.filter(s => s).join(delimiter);
}

function shortenURL(href, currentUrl = 'https://github.com') {
	if (!href) {
		return;
	}

	currentUrl = new URL(currentUrl);
	const currentRepo = currentUrl.pathname.slice(1).split('/', 2).join('/');

	/**
	 * Parse URL
	 */
	const {
		origin,
		pathname,
		search,
		hash
	} = new URL(href);

	const isRaw = [
		'https://raw.githubusercontent.com',
		'https://cdn.rawgit.com',
		'https://rawgit.com'
	].includes(origin);

	let [
		user,
		repo,
		type,
		revision,
		...filePath
	] = pathname.substr(1).split('/');

	if (isRaw) {
		[
			user,
			repo,
			// Raw URLs don't have `blob` here
			revision,
			...filePath
		] = pathname.substr(1).split('/');
		type = 'raw';
	}

	revision = styleRevision(revision);
	filePath = filePath.join('/');

	const isLocal = origin === currentUrl.origin;
	const isThisRepo = (isLocal || isRaw) && currentRepo === `${user}/${repo}`;
	const isReserved = reservedPaths.includes(user);
	const [, diffOrPatch] = pathname.match(patchDiffRegex) || [];
	const [, release] = pathname.match(releaseRegex) || [];
	const [, releaseTag, releaseTagExt] = pathname.match(releaseArchiveRegex) || [];
	const [, downloadTag, downloadFilename] = pathname.match(releaseDownloadRegex) || [];
	const [, label] = pathname.match(labelRegex) || [];
	const isFileOrDir = revision && [
		'raw',
		'tree',
		'blob',
		'blame',
		'commits'
	].includes(type);

	const repoUrl = isThisRepo ? '' : `${user}/${repo}`;

	/**
	 * Shorten URL
	 */

	if (isReserved || pathname === '/' || (!isLocal && !isRaw)) {
		return href
		.replace(/^https:[/][/]/, '')
		.replace(/^www[.]/, '')
		.replace(/[/]$/, '');
	}

	if (user && !repo) {
		return `@${user}${search}${hash}`;
	}

	if (isFileOrDir) {
		const file = `${repoUrl}${filePath ? (repoUrl ? ':' : '/') : ''}${filePath}`;
		const revisioned = joinValues([file, revision], '@');
		const partial = `${revisioned}${search}${hash}`;
		if (type !== 'blob' && type !== 'tree') {
			return `${partial} (${type})`;
		}
		return partial;
	}

	if (diffOrPatch) {
		const partial = joinValues([repoUrl, revision], '@');
		return `${partial}.${diffOrPatch}${search}${hash}`;
	}

	if (release) {
		const partial = joinValues([repoUrl, `<code>${release}</code>`], '@');
		return `${partial}${search}${hash} (release)`;
	}

	if (releaseTagExt) {
		const partial = joinValues([repoUrl, `<code>${releaseTag}</code>`], '@');
		return `${partial}${releaseTagExt}${search}${hash}`;
	}

	if (downloadFilename) {
		const partial = joinValues([repoUrl, `<code>${downloadTag}</code>`], '@');
		return `${partial} ${downloadFilename}${search}${hash} (download)`;
	}

	if (label) {
		return joinValues([repoUrl, label]) + `${search}${hash} (label)`;
	}

	// Drop leading and trailing slash of relative path
	return `${pathname.replace(/^[/]|[/]$/g, '')}${search}${hash}`;
}

function applyToLink(a, currentUrl) {
	// Shorten only if the link name hasn't been customized.
	// .href automatically adds a / to naked origins
	// so that needs to be tested too
	if (a.href === a.textContent || a.href === `${a.textContent}/`) {
		const shortened = shortenURL(a.href, currentUrl);
		// Only touch the dom is the URL has been shortened
		if (shortened !== a.textContent) {
			a.innerHTML = shortened;
			return true;
		}
	}
	return false;
}

module.exports = shortenURL;
module.exports.applyToLink = applyToLink;


/***/ }),
/* 15 */
/***/ (function(module, exports) {

/* global URL */
module.exports.URL = URL;


/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = ["400","401","402","403","404","405","406","407","408","409","410","411","412","413","414","415","416","417","418","419","420","421","422","423","424","425","426","427","428","429","430","431","500","501","502","503","504","505","506","507","508","509","510","511","about","access","account","admin","anonymous","api","apps","auth","billing","blog","business","cache","categories","changelog","codereview","comments","community","compare","contact","dashboard","design","developer","docs","downloads","editor","edu","enterprise","events","explore","features","files","gist","gists","graphs","help","home","hosting","images","info","integrations","issues","jobs","join","languages","legal","linux","lists","login","logout","mac","maintenance","marketplace","mine","mirrors","mobile","navigation","network","new","news","notifications","oauth","offer","open-source","organizations","orgs","pages","payments","personal","plans","plugins","popular","posts","press","pricing","projects","pulls","readme","releases","repositories","search","security","services","sessions","settings","shop","showcases","signin","signup","site","ssh","staff","stars","static","status","store","stories","styleguide","subscriptions","support","talks","teams","terms","tos","tour","translations","trending","updates","username","users","watching","wiki","windows","works-with","www1","www2","www3","www4","www5","www6","www7","www8","www9"]

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const semver = __webpack_require__(18);

module.exports = (versions, options) => {
	options = Object.assign({
		includePrereleases: true,
		clean: true
	}, options);

	let sortedVersions = versions.filter(x => semver.valid(x)).sort(semver.rcompare);

	if (!options.includePrereleases) {
		sortedVersions = sortedVersions.filter(x => semver.prerelease(x) === null);
	}

	if (options.clean) {
		sortedVersions = sortedVersions.map(x => semver.clean(x));
	}

	return sortedVersions;
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = SemVer;

// The debug function is excluded entirely from the minified version.
/* nomin */ var debug;
/* nomin */ if (false)
  /* nomin */ debug = function() {
    /* nomin */ var args = Array.prototype.slice.call(arguments, 0);
    /* nomin */ args.unshift('SEMVER');
    /* nomin */ console.log.apply(console, args);
    /* nomin */ };
/* nomin */ else
  /* nomin */ debug = function() {};

// Note: this is the semver.org version of the spec that it implements
// Not necessarily the package version of this code.
exports.SEMVER_SPEC_VERSION = '2.0.0';

var MAX_LENGTH = 256;
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;

// The actual regexps go on exports.re
var re = exports.re = [];
var src = exports.src = [];
var R = 0;

// The following Regular Expressions can be used for tokenizing,
// validating, and parsing SemVer version strings.

// ## Numeric Identifier
// A single `0`, or a non-zero digit followed by zero or more digits.

var NUMERICIDENTIFIER = R++;
src[NUMERICIDENTIFIER] = '0|[1-9]\\d*';
var NUMERICIDENTIFIERLOOSE = R++;
src[NUMERICIDENTIFIERLOOSE] = '[0-9]+';


// ## Non-numeric Identifier
// Zero or more digits, followed by a letter or hyphen, and then zero or
// more letters, digits, or hyphens.

var NONNUMERICIDENTIFIER = R++;
src[NONNUMERICIDENTIFIER] = '\\d*[a-zA-Z-][a-zA-Z0-9-]*';


// ## Main Version
// Three dot-separated numeric identifiers.

var MAINVERSION = R++;
src[MAINVERSION] = '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')';

var MAINVERSIONLOOSE = R++;
src[MAINVERSIONLOOSE] = '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')';

// ## Pre-release Version Identifier
// A numeric identifier, or a non-numeric identifier.

var PRERELEASEIDENTIFIER = R++;
src[PRERELEASEIDENTIFIER] = '(?:' + src[NUMERICIDENTIFIER] +
                            '|' + src[NONNUMERICIDENTIFIER] + ')';

var PRERELEASEIDENTIFIERLOOSE = R++;
src[PRERELEASEIDENTIFIERLOOSE] = '(?:' + src[NUMERICIDENTIFIERLOOSE] +
                                 '|' + src[NONNUMERICIDENTIFIER] + ')';


// ## Pre-release Version
// Hyphen, followed by one or more dot-separated pre-release version
// identifiers.

var PRERELEASE = R++;
src[PRERELEASE] = '(?:-(' + src[PRERELEASEIDENTIFIER] +
                  '(?:\\.' + src[PRERELEASEIDENTIFIER] + ')*))';

var PRERELEASELOOSE = R++;
src[PRERELEASELOOSE] = '(?:-?(' + src[PRERELEASEIDENTIFIERLOOSE] +
                       '(?:\\.' + src[PRERELEASEIDENTIFIERLOOSE] + ')*))';

// ## Build Metadata Identifier
// Any combination of digits, letters, or hyphens.

var BUILDIDENTIFIER = R++;
src[BUILDIDENTIFIER] = '[0-9A-Za-z-]+';

// ## Build Metadata
// Plus sign, followed by one or more period-separated build metadata
// identifiers.

var BUILD = R++;
src[BUILD] = '(?:\\+(' + src[BUILDIDENTIFIER] +
             '(?:\\.' + src[BUILDIDENTIFIER] + ')*))';


// ## Full Version String
// A main version, followed optionally by a pre-release version and
// build metadata.

// Note that the only major, minor, patch, and pre-release sections of
// the version string are capturing groups.  The build metadata is not a
// capturing group, because it should not ever be used in version
// comparison.

var FULL = R++;
var FULLPLAIN = 'v?' + src[MAINVERSION] +
                src[PRERELEASE] + '?' +
                src[BUILD] + '?';

src[FULL] = '^' + FULLPLAIN + '$';

// like full, but allows v1.2.3 and =1.2.3, which people do sometimes.
// also, 1.0.0alpha1 (prerelease without the hyphen) which is pretty
// common in the npm registry.
var LOOSEPLAIN = '[v=\\s]*' + src[MAINVERSIONLOOSE] +
                 src[PRERELEASELOOSE] + '?' +
                 src[BUILD] + '?';

var LOOSE = R++;
src[LOOSE] = '^' + LOOSEPLAIN + '$';

var GTLT = R++;
src[GTLT] = '((?:<|>)?=?)';

// Something like "2.*" or "1.2.x".
// Note that "x.x" is a valid xRange identifer, meaning "any version"
// Only the first item is strictly required.
var XRANGEIDENTIFIERLOOSE = R++;
src[XRANGEIDENTIFIERLOOSE] = src[NUMERICIDENTIFIERLOOSE] + '|x|X|\\*';
var XRANGEIDENTIFIER = R++;
src[XRANGEIDENTIFIER] = src[NUMERICIDENTIFIER] + '|x|X|\\*';

var XRANGEPLAIN = R++;
src[XRANGEPLAIN] = '[v=\\s]*(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:' + src[PRERELEASE] + ')?' +
                   src[BUILD] + '?' +
                   ')?)?';

var XRANGEPLAINLOOSE = R++;
src[XRANGEPLAINLOOSE] = '[v=\\s]*(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:' + src[PRERELEASELOOSE] + ')?' +
                        src[BUILD] + '?' +
                        ')?)?';

var XRANGE = R++;
src[XRANGE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAIN] + '$';
var XRANGELOOSE = R++;
src[XRANGELOOSE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAINLOOSE] + '$';

// Tilde ranges.
// Meaning is "reasonably at or greater than"
var LONETILDE = R++;
src[LONETILDE] = '(?:~>?)';

var TILDETRIM = R++;
src[TILDETRIM] = '(\\s*)' + src[LONETILDE] + '\\s+';
re[TILDETRIM] = new RegExp(src[TILDETRIM], 'g');
var tildeTrimReplace = '$1~';

var TILDE = R++;
src[TILDE] = '^' + src[LONETILDE] + src[XRANGEPLAIN] + '$';
var TILDELOOSE = R++;
src[TILDELOOSE] = '^' + src[LONETILDE] + src[XRANGEPLAINLOOSE] + '$';

// Caret ranges.
// Meaning is "at least and backwards compatible with"
var LONECARET = R++;
src[LONECARET] = '(?:\\^)';

var CARETTRIM = R++;
src[CARETTRIM] = '(\\s*)' + src[LONECARET] + '\\s+';
re[CARETTRIM] = new RegExp(src[CARETTRIM], 'g');
var caretTrimReplace = '$1^';

var CARET = R++;
src[CARET] = '^' + src[LONECARET] + src[XRANGEPLAIN] + '$';
var CARETLOOSE = R++;
src[CARETLOOSE] = '^' + src[LONECARET] + src[XRANGEPLAINLOOSE] + '$';

// A simple gt/lt/eq thing, or just "" to indicate "any version"
var COMPARATORLOOSE = R++;
src[COMPARATORLOOSE] = '^' + src[GTLT] + '\\s*(' + LOOSEPLAIN + ')$|^$';
var COMPARATOR = R++;
src[COMPARATOR] = '^' + src[GTLT] + '\\s*(' + FULLPLAIN + ')$|^$';


// An expression to strip any whitespace between the gtlt and the thing
// it modifies, so that `> 1.2.3` ==> `>1.2.3`
var COMPARATORTRIM = R++;
src[COMPARATORTRIM] = '(\\s*)' + src[GTLT] +
                      '\\s*(' + LOOSEPLAIN + '|' + src[XRANGEPLAIN] + ')';

// this one has to use the /g flag
re[COMPARATORTRIM] = new RegExp(src[COMPARATORTRIM], 'g');
var comparatorTrimReplace = '$1$2$3';


// Something like `1.2.3 - 1.2.4`
// Note that these all use the loose form, because they'll be
// checked against either the strict or loose comparator form
// later.
var HYPHENRANGE = R++;
src[HYPHENRANGE] = '^\\s*(' + src[XRANGEPLAIN] + ')' +
                   '\\s+-\\s+' +
                   '(' + src[XRANGEPLAIN] + ')' +
                   '\\s*$';

var HYPHENRANGELOOSE = R++;
src[HYPHENRANGELOOSE] = '^\\s*(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s+-\\s+' +
                        '(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s*$';

// Star ranges basically just allow anything at all.
var STAR = R++;
src[STAR] = '(<|>)?=?\\s*\\*';

// Compile to actual regexp objects.
// All are flag-free, unless they were created above with a flag.
for (var i = 0; i < R; i++) {
  debug(i, src[i]);
  if (!re[i])
    re[i] = new RegExp(src[i]);
}

exports.parse = parse;
function parse(version, loose) {
  if (version instanceof SemVer)
    return version;

  if (typeof version !== 'string')
    return null;

  if (version.length > MAX_LENGTH)
    return null;

  var r = loose ? re[LOOSE] : re[FULL];
  if (!r.test(version))
    return null;

  try {
    return new SemVer(version, loose);
  } catch (er) {
    return null;
  }
}

exports.valid = valid;
function valid(version, loose) {
  var v = parse(version, loose);
  return v ? v.version : null;
}


exports.clean = clean;
function clean(version, loose) {
  var s = parse(version.trim().replace(/^[=v]+/, ''), loose);
  return s ? s.version : null;
}

exports.SemVer = SemVer;

function SemVer(version, loose) {
  if (version instanceof SemVer) {
    if (version.loose === loose)
      return version;
    else
      version = version.version;
  } else if (typeof version !== 'string') {
    throw new TypeError('Invalid Version: ' + version);
  }

  if (version.length > MAX_LENGTH)
    throw new TypeError('version is longer than ' + MAX_LENGTH + ' characters')

  if (!(this instanceof SemVer))
    return new SemVer(version, loose);

  debug('SemVer', version, loose);
  this.loose = loose;
  var m = version.trim().match(loose ? re[LOOSE] : re[FULL]);

  if (!m)
    throw new TypeError('Invalid Version: ' + version);

  this.raw = version;

  // these are actually numbers
  this.major = +m[1];
  this.minor = +m[2];
  this.patch = +m[3];

  if (this.major > MAX_SAFE_INTEGER || this.major < 0)
    throw new TypeError('Invalid major version')

  if (this.minor > MAX_SAFE_INTEGER || this.minor < 0)
    throw new TypeError('Invalid minor version')

  if (this.patch > MAX_SAFE_INTEGER || this.patch < 0)
    throw new TypeError('Invalid patch version')

  // numberify any prerelease numeric ids
  if (!m[4])
    this.prerelease = [];
  else
    this.prerelease = m[4].split('.').map(function(id) {
      if (/^[0-9]+$/.test(id)) {
        var num = +id;
        if (num >= 0 && num < MAX_SAFE_INTEGER)
          return num;
      }
      return id;
    });

  this.build = m[5] ? m[5].split('.') : [];
  this.format();
}

SemVer.prototype.format = function() {
  this.version = this.major + '.' + this.minor + '.' + this.patch;
  if (this.prerelease.length)
    this.version += '-' + this.prerelease.join('.');
  return this.version;
};

SemVer.prototype.toString = function() {
  return this.version;
};

SemVer.prototype.compare = function(other) {
  debug('SemVer.compare', this.version, this.loose, other);
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return this.compareMain(other) || this.comparePre(other);
};

SemVer.prototype.compareMain = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return compareIdentifiers(this.major, other.major) ||
         compareIdentifiers(this.minor, other.minor) ||
         compareIdentifiers(this.patch, other.patch);
};

SemVer.prototype.comparePre = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  // NOT having a prerelease is > having one
  if (this.prerelease.length && !other.prerelease.length)
    return -1;
  else if (!this.prerelease.length && other.prerelease.length)
    return 1;
  else if (!this.prerelease.length && !other.prerelease.length)
    return 0;

  var i = 0;
  do {
    var a = this.prerelease[i];
    var b = other.prerelease[i];
    debug('prerelease compare', i, a, b);
    if (a === undefined && b === undefined)
      return 0;
    else if (b === undefined)
      return 1;
    else if (a === undefined)
      return -1;
    else if (a === b)
      continue;
    else
      return compareIdentifiers(a, b);
  } while (++i);
};

// preminor will bump the version up to the next minor release, and immediately
// down to pre-release. premajor and prepatch work the same way.
SemVer.prototype.inc = function(release, identifier) {
  switch (release) {
    case 'premajor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor = 0;
      this.major++;
      this.inc('pre', identifier);
      break;
    case 'preminor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor++;
      this.inc('pre', identifier);
      break;
    case 'prepatch':
      // If this is already a prerelease, it will bump to the next version
      // drop any prereleases that might already exist, since they are not
      // relevant at this point.
      this.prerelease.length = 0;
      this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;
    // If the input is a non-prerelease version, this acts the same as
    // prepatch.
    case 'prerelease':
      if (this.prerelease.length === 0)
        this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;

    case 'major':
      // If this is a pre-major version, bump up to the same major version.
      // Otherwise increment major.
      // 1.0.0-5 bumps to 1.0.0
      // 1.1.0 bumps to 2.0.0
      if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0)
        this.major++;
      this.minor = 0;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'minor':
      // If this is a pre-minor version, bump up to the same minor version.
      // Otherwise increment minor.
      // 1.2.0-5 bumps to 1.2.0
      // 1.2.1 bumps to 1.3.0
      if (this.patch !== 0 || this.prerelease.length === 0)
        this.minor++;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'patch':
      // If this is not a pre-release version, it will increment the patch.
      // If it is a pre-release it will bump up to the same patch version.
      // 1.2.0-5 patches to 1.2.0
      // 1.2.0 patches to 1.2.1
      if (this.prerelease.length === 0)
        this.patch++;
      this.prerelease = [];
      break;
    // This probably shouldn't be used publicly.
    // 1.0.0 "pre" would become 1.0.0-0 which is the wrong direction.
    case 'pre':
      if (this.prerelease.length === 0)
        this.prerelease = [0];
      else {
        var i = this.prerelease.length;
        while (--i >= 0) {
          if (typeof this.prerelease[i] === 'number') {
            this.prerelease[i]++;
            i = -2;
          }
        }
        if (i === -1) // didn't increment anything
          this.prerelease.push(0);
      }
      if (identifier) {
        // 1.2.0-beta.1 bumps to 1.2.0-beta.2,
        // 1.2.0-beta.fooblz or 1.2.0-beta bumps to 1.2.0-beta.0
        if (this.prerelease[0] === identifier) {
          if (isNaN(this.prerelease[1]))
            this.prerelease = [identifier, 0];
        } else
          this.prerelease = [identifier, 0];
      }
      break;

    default:
      throw new Error('invalid increment argument: ' + release);
  }
  this.format();
  this.raw = this.version;
  return this;
};

exports.inc = inc;
function inc(version, release, loose, identifier) {
  if (typeof(loose) === 'string') {
    identifier = loose;
    loose = undefined;
  }

  try {
    return new SemVer(version, loose).inc(release, identifier).version;
  } catch (er) {
    return null;
  }
}

exports.diff = diff;
function diff(version1, version2) {
  if (eq(version1, version2)) {
    return null;
  } else {
    var v1 = parse(version1);
    var v2 = parse(version2);
    if (v1.prerelease.length || v2.prerelease.length) {
      for (var key in v1) {
        if (key === 'major' || key === 'minor' || key === 'patch') {
          if (v1[key] !== v2[key]) {
            return 'pre'+key;
          }
        }
      }
      return 'prerelease';
    }
    for (var key in v1) {
      if (key === 'major' || key === 'minor' || key === 'patch') {
        if (v1[key] !== v2[key]) {
          return key;
        }
      }
    }
  }
}

exports.compareIdentifiers = compareIdentifiers;

var numeric = /^[0-9]+$/;
function compareIdentifiers(a, b) {
  var anum = numeric.test(a);
  var bnum = numeric.test(b);

  if (anum && bnum) {
    a = +a;
    b = +b;
  }

  return (anum && !bnum) ? -1 :
         (bnum && !anum) ? 1 :
         a < b ? -1 :
         a > b ? 1 :
         0;
}

exports.rcompareIdentifiers = rcompareIdentifiers;
function rcompareIdentifiers(a, b) {
  return compareIdentifiers(b, a);
}

exports.major = major;
function major(a, loose) {
  return new SemVer(a, loose).major;
}

exports.minor = minor;
function minor(a, loose) {
  return new SemVer(a, loose).minor;
}

exports.patch = patch;
function patch(a, loose) {
  return new SemVer(a, loose).patch;
}

exports.compare = compare;
function compare(a, b, loose) {
  return new SemVer(a, loose).compare(new SemVer(b, loose));
}

exports.compareLoose = compareLoose;
function compareLoose(a, b) {
  return compare(a, b, true);
}

exports.rcompare = rcompare;
function rcompare(a, b, loose) {
  return compare(b, a, loose);
}

exports.sort = sort;
function sort(list, loose) {
  return list.sort(function(a, b) {
    return exports.compare(a, b, loose);
  });
}

exports.rsort = rsort;
function rsort(list, loose) {
  return list.sort(function(a, b) {
    return exports.rcompare(a, b, loose);
  });
}

exports.gt = gt;
function gt(a, b, loose) {
  return compare(a, b, loose) > 0;
}

exports.lt = lt;
function lt(a, b, loose) {
  return compare(a, b, loose) < 0;
}

exports.eq = eq;
function eq(a, b, loose) {
  return compare(a, b, loose) === 0;
}

exports.neq = neq;
function neq(a, b, loose) {
  return compare(a, b, loose) !== 0;
}

exports.gte = gte;
function gte(a, b, loose) {
  return compare(a, b, loose) >= 0;
}

exports.lte = lte;
function lte(a, b, loose) {
  return compare(a, b, loose) <= 0;
}

exports.cmp = cmp;
function cmp(a, op, b, loose) {
  var ret;
  switch (op) {
    case '===':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a === b;
      break;
    case '!==':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a !== b;
      break;
    case '': case '=': case '==': ret = eq(a, b, loose); break;
    case '!=': ret = neq(a, b, loose); break;
    case '>': ret = gt(a, b, loose); break;
    case '>=': ret = gte(a, b, loose); break;
    case '<': ret = lt(a, b, loose); break;
    case '<=': ret = lte(a, b, loose); break;
    default: throw new TypeError('Invalid operator: ' + op);
  }
  return ret;
}

exports.Comparator = Comparator;
function Comparator(comp, loose) {
  if (comp instanceof Comparator) {
    if (comp.loose === loose)
      return comp;
    else
      comp = comp.value;
  }

  if (!(this instanceof Comparator))
    return new Comparator(comp, loose);

  debug('comparator', comp, loose);
  this.loose = loose;
  this.parse(comp);

  if (this.semver === ANY)
    this.value = '';
  else
    this.value = this.operator + this.semver.version;

  debug('comp', this);
}

var ANY = {};
Comparator.prototype.parse = function(comp) {
  var r = this.loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var m = comp.match(r);

  if (!m)
    throw new TypeError('Invalid comparator: ' + comp);

  this.operator = m[1];
  if (this.operator === '=')
    this.operator = '';

  // if it literally is just '>' or '' then allow anything.
  if (!m[2])
    this.semver = ANY;
  else
    this.semver = new SemVer(m[2], this.loose);
};

Comparator.prototype.toString = function() {
  return this.value;
};

Comparator.prototype.test = function(version) {
  debug('Comparator.test', version, this.loose);

  if (this.semver === ANY)
    return true;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  return cmp(version, this.operator, this.semver, this.loose);
};

Comparator.prototype.intersects = function(comp, loose) {
  if (!(comp instanceof Comparator)) {
    throw new TypeError('a Comparator is required');
  }

  var rangeTmp;

  if (this.operator === '') {
    rangeTmp = new Range(comp.value, loose);
    return satisfies(this.value, rangeTmp, loose);
  } else if (comp.operator === '') {
    rangeTmp = new Range(this.value, loose);
    return satisfies(comp.semver, rangeTmp, loose);
  }

  var sameDirectionIncreasing =
    (this.operator === '>=' || this.operator === '>') &&
    (comp.operator === '>=' || comp.operator === '>');
  var sameDirectionDecreasing =
    (this.operator === '<=' || this.operator === '<') &&
    (comp.operator === '<=' || comp.operator === '<');
  var sameSemVer = this.semver.version === comp.semver.version;
  var differentDirectionsInclusive =
    (this.operator === '>=' || this.operator === '<=') &&
    (comp.operator === '>=' || comp.operator === '<=');
  var oppositeDirectionsLessThan =
    cmp(this.semver, '<', comp.semver, loose) &&
    ((this.operator === '>=' || this.operator === '>') &&
    (comp.operator === '<=' || comp.operator === '<'));
  var oppositeDirectionsGreaterThan =
    cmp(this.semver, '>', comp.semver, loose) &&
    ((this.operator === '<=' || this.operator === '<') &&
    (comp.operator === '>=' || comp.operator === '>'));

  return sameDirectionIncreasing || sameDirectionDecreasing ||
    (sameSemVer && differentDirectionsInclusive) ||
    oppositeDirectionsLessThan || oppositeDirectionsGreaterThan;
};


exports.Range = Range;
function Range(range, loose) {
  if (range instanceof Range) {
    if (range.loose === loose) {
      return range;
    } else {
      return new Range(range.raw, loose);
    }
  }

  if (range instanceof Comparator) {
    return new Range(range.value, loose);
  }

  if (!(this instanceof Range))
    return new Range(range, loose);

  this.loose = loose;

  // First, split based on boolean or ||
  this.raw = range;
  this.set = range.split(/\s*\|\|\s*/).map(function(range) {
    return this.parseRange(range.trim());
  }, this).filter(function(c) {
    // throw out any that are not relevant for whatever reason
    return c.length;
  });

  if (!this.set.length) {
    throw new TypeError('Invalid SemVer Range: ' + range);
  }

  this.format();
}

Range.prototype.format = function() {
  this.range = this.set.map(function(comps) {
    return comps.join(' ').trim();
  }).join('||').trim();
  return this.range;
};

Range.prototype.toString = function() {
  return this.range;
};

Range.prototype.parseRange = function(range) {
  var loose = this.loose;
  range = range.trim();
  debug('range', range, loose);
  // `1.2.3 - 1.2.4` => `>=1.2.3 <=1.2.4`
  var hr = loose ? re[HYPHENRANGELOOSE] : re[HYPHENRANGE];
  range = range.replace(hr, hyphenReplace);
  debug('hyphen replace', range);
  // `> 1.2.3 < 1.2.5` => `>1.2.3 <1.2.5`
  range = range.replace(re[COMPARATORTRIM], comparatorTrimReplace);
  debug('comparator trim', range, re[COMPARATORTRIM]);

  // `~ 1.2.3` => `~1.2.3`
  range = range.replace(re[TILDETRIM], tildeTrimReplace);

  // `^ 1.2.3` => `^1.2.3`
  range = range.replace(re[CARETTRIM], caretTrimReplace);

  // normalize spaces
  range = range.split(/\s+/).join(' ');

  // At this point, the range is completely trimmed and
  // ready to be split into comparators.

  var compRe = loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var set = range.split(' ').map(function(comp) {
    return parseComparator(comp, loose);
  }).join(' ').split(/\s+/);
  if (this.loose) {
    // in loose mode, throw out any that are not valid comparators
    set = set.filter(function(comp) {
      return !!comp.match(compRe);
    });
  }
  set = set.map(function(comp) {
    return new Comparator(comp, loose);
  });

  return set;
};

Range.prototype.intersects = function(range, loose) {
  if (!(range instanceof Range)) {
    throw new TypeError('a Range is required');
  }

  return this.set.some(function(thisComparators) {
    return thisComparators.every(function(thisComparator) {
      return range.set.some(function(rangeComparators) {
        return rangeComparators.every(function(rangeComparator) {
          return thisComparator.intersects(rangeComparator, loose);
        });
      });
    });
  });
};

// Mostly just for testing and legacy API reasons
exports.toComparators = toComparators;
function toComparators(range, loose) {
  return new Range(range, loose).set.map(function(comp) {
    return comp.map(function(c) {
      return c.value;
    }).join(' ').trim().split(' ');
  });
}

// comprised of xranges, tildes, stars, and gtlt's at this point.
// already replaced the hyphen ranges
// turn into a set of JUST comparators.
function parseComparator(comp, loose) {
  debug('comp', comp);
  comp = replaceCarets(comp, loose);
  debug('caret', comp);
  comp = replaceTildes(comp, loose);
  debug('tildes', comp);
  comp = replaceXRanges(comp, loose);
  debug('xrange', comp);
  comp = replaceStars(comp, loose);
  debug('stars', comp);
  return comp;
}

function isX(id) {
  return !id || id.toLowerCase() === 'x' || id === '*';
}

// ~, ~> --> * (any, kinda silly)
// ~2, ~2.x, ~2.x.x, ~>2, ~>2.x ~>2.x.x --> >=2.0.0 <3.0.0
// ~2.0, ~2.0.x, ~>2.0, ~>2.0.x --> >=2.0.0 <2.1.0
// ~1.2, ~1.2.x, ~>1.2, ~>1.2.x --> >=1.2.0 <1.3.0
// ~1.2.3, ~>1.2.3 --> >=1.2.3 <1.3.0
// ~1.2.0, ~>1.2.0 --> >=1.2.0 <1.3.0
function replaceTildes(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceTilde(comp, loose);
  }).join(' ');
}

function replaceTilde(comp, loose) {
  var r = loose ? re[TILDELOOSE] : re[TILDE];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('tilde', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p))
      // ~1.2 == >=1.2.0 <1.3.0
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    else if (pr) {
      debug('replaceTilde pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      ret = '>=' + M + '.' + m + '.' + p + pr +
            ' <' + M + '.' + (+m + 1) + '.0';
    } else
      // ~1.2.3 == >=1.2.3 <1.3.0
      ret = '>=' + M + '.' + m + '.' + p +
            ' <' + M + '.' + (+m + 1) + '.0';

    debug('tilde return', ret);
    return ret;
  });
}

// ^ --> * (any, kinda silly)
// ^2, ^2.x, ^2.x.x --> >=2.0.0 <3.0.0
// ^2.0, ^2.0.x --> >=2.0.0 <3.0.0
// ^1.2, ^1.2.x --> >=1.2.0 <2.0.0
// ^1.2.3 --> >=1.2.3 <2.0.0
// ^1.2.0 --> >=1.2.0 <2.0.0
function replaceCarets(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceCaret(comp, loose);
  }).join(' ');
}

function replaceCaret(comp, loose) {
  debug('caret', comp, loose);
  var r = loose ? re[CARETLOOSE] : re[CARET];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('caret', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p)) {
      if (M === '0')
        ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
      else
        ret = '>=' + M + '.' + m + '.0 <' + (+M + 1) + '.0.0';
    } else if (pr) {
      debug('replaceCaret pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p + pr +
              ' <' + (+M + 1) + '.0.0';
    } else {
      debug('no pr');
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p +
              ' <' + (+M + 1) + '.0.0';
    }

    debug('caret return', ret);
    return ret;
  });
}

function replaceXRanges(comp, loose) {
  debug('replaceXRanges', comp, loose);
  return comp.split(/\s+/).map(function(comp) {
    return replaceXRange(comp, loose);
  }).join(' ');
}

function replaceXRange(comp, loose) {
  comp = comp.trim();
  var r = loose ? re[XRANGELOOSE] : re[XRANGE];
  return comp.replace(r, function(ret, gtlt, M, m, p, pr) {
    debug('xRange', comp, ret, gtlt, M, m, p, pr);
    var xM = isX(M);
    var xm = xM || isX(m);
    var xp = xm || isX(p);
    var anyX = xp;

    if (gtlt === '=' && anyX)
      gtlt = '';

    if (xM) {
      if (gtlt === '>' || gtlt === '<') {
        // nothing is allowed
        ret = '<0.0.0';
      } else {
        // nothing is forbidden
        ret = '*';
      }
    } else if (gtlt && anyX) {
      // replace X with 0
      if (xm)
        m = 0;
      if (xp)
        p = 0;

      if (gtlt === '>') {
        // >1 => >=2.0.0
        // >1.2 => >=1.3.0
        // >1.2.3 => >= 1.2.4
        gtlt = '>=';
        if (xm) {
          M = +M + 1;
          m = 0;
          p = 0;
        } else if (xp) {
          m = +m + 1;
          p = 0;
        }
      } else if (gtlt === '<=') {
        // <=0.7.x is actually <0.8.0, since any 0.7.x should
        // pass.  Similarly, <=7.x is actually <8.0.0, etc.
        gtlt = '<';
        if (xm)
          M = +M + 1;
        else
          m = +m + 1;
      }

      ret = gtlt + M + '.' + m + '.' + p;
    } else if (xm) {
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    } else if (xp) {
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    }

    debug('xRange return', ret);

    return ret;
  });
}

// Because * is AND-ed with everything else in the comparator,
// and '' means "any version", just remove the *s entirely.
function replaceStars(comp, loose) {
  debug('replaceStars', comp, loose);
  // Looseness is ignored here.  star is always as loose as it gets!
  return comp.trim().replace(re[STAR], '');
}

// This function is passed to string.replace(re[HYPHENRANGE])
// M, m, patch, prerelease, build
// 1.2 - 3.4.5 => >=1.2.0 <=3.4.5
// 1.2.3 - 3.4 => >=1.2.0 <3.5.0 Any 3.4.x will do
// 1.2 - 3.4 => >=1.2.0 <3.5.0
function hyphenReplace($0,
                       from, fM, fm, fp, fpr, fb,
                       to, tM, tm, tp, tpr, tb) {

  if (isX(fM))
    from = '';
  else if (isX(fm))
    from = '>=' + fM + '.0.0';
  else if (isX(fp))
    from = '>=' + fM + '.' + fm + '.0';
  else
    from = '>=' + from;

  if (isX(tM))
    to = '';
  else if (isX(tm))
    to = '<' + (+tM + 1) + '.0.0';
  else if (isX(tp))
    to = '<' + tM + '.' + (+tm + 1) + '.0';
  else if (tpr)
    to = '<=' + tM + '.' + tm + '.' + tp + '-' + tpr;
  else
    to = '<=' + to;

  return (from + ' ' + to).trim();
}


// if ANY of the sets match ALL of its comparators, then pass
Range.prototype.test = function(version) {
  if (!version)
    return false;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  for (var i = 0; i < this.set.length; i++) {
    if (testSet(this.set[i], version))
      return true;
  }
  return false;
};

function testSet(set, version) {
  for (var i = 0; i < set.length; i++) {
    if (!set[i].test(version))
      return false;
  }

  if (version.prerelease.length) {
    // Find the set of versions that are allowed to have prereleases
    // For example, ^1.2.3-pr.1 desugars to >=1.2.3-pr.1 <2.0.0
    // That should allow `1.2.3-pr.2` to pass.
    // However, `1.2.4-alpha.notready` should NOT be allowed,
    // even though it's within the range set by the comparators.
    for (var i = 0; i < set.length; i++) {
      debug(set[i].semver);
      if (set[i].semver === ANY)
        continue;

      if (set[i].semver.prerelease.length > 0) {
        var allowed = set[i].semver;
        if (allowed.major === version.major &&
            allowed.minor === version.minor &&
            allowed.patch === version.patch)
          return true;
      }
    }

    // Version has a -pre, but it's not one of the ones we like.
    return false;
  }

  return true;
}

exports.satisfies = satisfies;
function satisfies(version, range, loose) {
  try {
    range = new Range(range, loose);
  } catch (er) {
    return false;
  }
  return range.test(version);
}

exports.maxSatisfying = maxSatisfying;
function maxSatisfying(versions, range, loose) {
  var max = null;
  var maxSV = null;
  try {
    var rangeObj = new Range(range, loose);
  } catch (er) {
    return null;
  }
  versions.forEach(function (v) {
    if (rangeObj.test(v)) { // satisfies(v, range, loose)
      if (!max || maxSV.compare(v) === -1) { // compare(max, v, true)
        max = v;
        maxSV = new SemVer(max, loose);
      }
    }
  })
  return max;
}

exports.minSatisfying = minSatisfying;
function minSatisfying(versions, range, loose) {
  var min = null;
  var minSV = null;
  try {
    var rangeObj = new Range(range, loose);
  } catch (er) {
    return null;
  }
  versions.forEach(function (v) {
    if (rangeObj.test(v)) { // satisfies(v, range, loose)
      if (!min || minSV.compare(v) === 1) { // compare(min, v, true)
        min = v;
        minSV = new SemVer(min, loose);
      }
    }
  })
  return min;
}

exports.validRange = validRange;
function validRange(range, loose) {
  try {
    // Return '*' instead of '' so that truthiness works.
    // This will throw if it's invalid anyway
    return new Range(range, loose).range || '*';
  } catch (er) {
    return null;
  }
}

// Determine if version is less than all the versions possible in the range
exports.ltr = ltr;
function ltr(version, range, loose) {
  return outside(version, range, '<', loose);
}

// Determine if version is greater than all the versions possible in the range.
exports.gtr = gtr;
function gtr(version, range, loose) {
  return outside(version, range, '>', loose);
}

exports.outside = outside;
function outside(version, range, hilo, loose) {
  version = new SemVer(version, loose);
  range = new Range(range, loose);

  var gtfn, ltefn, ltfn, comp, ecomp;
  switch (hilo) {
    case '>':
      gtfn = gt;
      ltefn = lte;
      ltfn = lt;
      comp = '>';
      ecomp = '>=';
      break;
    case '<':
      gtfn = lt;
      ltefn = gte;
      ltfn = gt;
      comp = '<';
      ecomp = '<=';
      break;
    default:
      throw new TypeError('Must provide a hilo val of "<" or ">"');
  }

  // If it satisifes the range it is not outside
  if (satisfies(version, range, loose)) {
    return false;
  }

  // From now on, variable terms are as if we're in "gtr" mode.
  // but note that everything is flipped for the "ltr" function.

  for (var i = 0; i < range.set.length; ++i) {
    var comparators = range.set[i];

    var high = null;
    var low = null;

    comparators.forEach(function(comparator) {
      if (comparator.semver === ANY) {
        comparator = new Comparator('>=0.0.0')
      }
      high = high || comparator;
      low = low || comparator;
      if (gtfn(comparator.semver, high.semver, loose)) {
        high = comparator;
      } else if (ltfn(comparator.semver, low.semver, loose)) {
        low = comparator;
      }
    });

    // If the edge version comparator has a operator then our version
    // isn't outside it
    if (high.operator === comp || high.operator === ecomp) {
      return false;
    }

    // If the lowest version comparator has an operator and our version
    // is less than it then it isn't higher than the range
    if ((!low.operator || low.operator === comp) &&
        ltefn(version, low.semver)) {
      return false;
    } else if (low.operator === ecomp && ltfn(version, low.semver)) {
      return false;
    }
  }
  return true;
}

exports.prerelease = prerelease;
function prerelease(version, loose) {
  var parsed = parse(version, loose);
  return (parsed && parsed.prerelease.length) ? parsed.prerelease : null;
}

exports.intersects = intersects;
function intersects(r1, r2, loose) {
  r1 = new Range(r1, loose)
  r2 = new Range(r2, loose)
  return r1.intersects(r2)
}


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = () => (/(?:[\w-.]+\/[\w-.]+)?#[1-9]\d*/g);


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const escapeGoat = __webpack_require__(21);

module.exports = input => {
	const attributes = [];

	for (const key of Object.keys(input)) {
		let value = input[key];

		if (value === false) {
			continue;
		}

		if (Array.isArray(value)) {
			value = value.join(' ');
		}

		let attribute = escapeGoat.escape(key);

		if (value !== true) {
			attribute += `="${escapeGoat.escape(String(value))}"`;
		}

		attributes.push(attribute);
	}

	return attributes.length > 0 ? ' ' + attributes.join(' ') : '';
};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.escape = input => input
	.replace(/&/g, '&amp;')
	.replace(/"/g, '&quot;')
	.replace(/'/g, '&#39;')
	.replace(/</g, '&lt;')
	.replace(/>/g, '&gt;');

exports.unescape = input => input
	.replace(/&gt;/g, '>')
	.replace(/&lt;/g, '<')
	.replace(/&#39;/g, '\'')
	.replace(/&quot;/g, '"')
	.replace(/&amp;/g, '&');

exports.escapeTag = function (input) {
	let output = input[0];
	for (let i = 1; i < arguments.length; i++) {
		output = output + exports.escape(arguments[i]) + input[i];
	}
	return output;
};

exports.unescapeTag = function (input) {
	let output = input[0];
	for (let i = 1; i < arguments.length; i++) {
		output = output + exports.unescape(arguments[i]) + input[i];
	}
	return output;
};


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = __webpack_require__(23);


/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = ["area","base","br","col","embed","hr","img","input","link","menuitem","meta","param","source","track","wbr"]

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = ["a","altGlyph","altGlyphDef","altGlyphItem","animate","animateColor","animateMotion","animateTransform","animation","audio","canvas","circle","clipPath","color-profile","cursor","defs","desc","discard","ellipse","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","filter","font","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignObject","g","glyph","glyphRef","handler","hatch","hatchpath","hkern","iframe","image","line","linearGradient","listener","marker","mask","mesh","meshgradient","meshpatch","meshrow","metadata","missing-glyph","mpath","path","pattern","polygon","polyline","prefetch","radialGradient","rect","script","set","solidColor","solidcolor","stop","style","svg","switch","symbol","tbreak","text","textArea","textPath","title","tref","tspan","unknown","use","video","view","vkern"]

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
  Copyright (c) 2016 Jed Watson.
  Licensed under the MIT License (MIT), see
  http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;

	function classNames () {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg)) {
				classes.push(classNames.apply(null, arg));
			} else if (argType === 'object') {
				for (var key in arg) {
					if (hasOwn.call(arg, key) && arg[key]) {
						classes.push(key);
					}
				}
			}
		}

		return classes.join(' ');
	}

	if (typeof module !== 'undefined' && module.exports) {
		module.exports = classNames;
	} else if (true) {
		// register as 'classnames', consistent with npm package name
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function () {
			return classNames;
		}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else {
		window.classNames = classNames;
	}
}());


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * arr-flatten <https://github.com/jonschlinkert/arr-flatten>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */



module.exports = function (arr) {
  return flat(arr, []);
};

function flat(arr, res) {
  var i = 0, cur;
  var len = arr.length;
  for (; i < len; i++) {
    cur = arr[i];
    Array.isArray(cur) ? flat(cur, res) : res.push(cur);
  }
  return res;
}


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * object.omit <https://github.com/jonschlinkert/object.omit>
 *
 * Copyright (c) 2014-2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */



var isObject = __webpack_require__(28);
var forOwn = __webpack_require__(29);

module.exports = function omit(obj, keys) {
  if (!isObject(obj)) return {};

  keys = [].concat.apply([], [].slice.call(arguments, 1));
  var last = keys[keys.length - 1];
  var res = {}, fn;

  if (typeof last === 'function') {
    fn = keys.pop();
  }

  var isFunction = typeof fn === 'function';
  if (!keys.length && !isFunction) {
    return obj;
  }

  forOwn(obj, function(value, key) {
    if (keys.indexOf(key) === -1) {

      if (!isFunction) {
        res[key] = value;
      } else if (fn(value, key, obj)) {
        res[key] = value;
      }
    }
  });
  return res;
};


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * is-extendable <https://github.com/jonschlinkert/is-extendable>
 *
 * Copyright (c) 2015, Jon Schlinkert.
 * Licensed under the MIT License.
 */



module.exports = function isExtendable(val) {
  return typeof val !== 'undefined' && val !== null
    && (typeof val === 'object' || typeof val === 'function');
};


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * for-own <https://github.com/jonschlinkert/for-own>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */



var forIn = __webpack_require__(30);
var hasOwn = Object.prototype.hasOwnProperty;

module.exports = function forOwn(obj, fn, thisArg) {
  forIn(obj, function(val, key) {
    if (hasOwn.call(obj, key)) {
      return fn.call(thisArg, obj[key], key, obj);
    }
  });
};


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*!
 * for-in <https://github.com/jonschlinkert/for-in>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */



module.exports = function forIn(obj, fn, thisArg) {
  for (var key in obj) {
    if (fn.call(thisArg, obj[key], key, obj) === false) {
      break;
    }
  }
};


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else if (typeof exports !== "undefined") {
    factory(module);
  } else {
    var mod = {
      exports: {}
    };
    factory(mod);
    global.browser = mod.exports;
  }
})(this, function (module) {
  /* webextension-polyfill - v0.1.1 - Thu Apr 13 2017 13:15:15 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (typeof browser === "undefined") {
    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = () => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "export": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "import": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "downloads": {
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getBrowserInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.rejection
       *        The promise's rejection function.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = promise => {
        return (...callbackArgs) => {
          if (chrome.runtime.lastError) {
            promise.reject(chrome.runtime.lastError);
          } else if (callbackArgs.length === 1) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            target[name](...args, makeCallback({ resolve, reject }));
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the orginal method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);

        let handlers = {
          has(target, prop) {
            return prop in target || prop in cache;
          },

          get(target, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });

              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(target, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },

          defineProperty(target, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(target, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        return new Proxy(target, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });

      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let result = listener(message, sender);

          if (isThenable(result)) {
            result.then(sendResponse, error => {
              console.error(error);
              sendResponse(error);
            });

            return true;
          } else if (result !== undefined) {
            sendResponse(result);
          }
        };
      });

      const staticWrappers = {
        runtime: {
          onMessage: wrapEvent(onMessageWrappers)
        }
      };

      return wrapObject(chrome, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(); // eslint-disable-line no-undef
  } else {
    module.exports = browser; // eslint-disable-line no-undef
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = (to, from) => {
	// TODO: use `Reflect.ownKeys()` when targeting Node.js 6
	for (const prop of Object.getOwnPropertyNames(from).concat(Object.getOwnPropertySymbols(from))) {
		Object.defineProperty(to, prop, Object.getOwnPropertyDescriptor(from, prop));
	}
};


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* globals document */


// - const urlRegex = require('url-regex');
const createHtmlElement = __webpack_require__(9);

// Capture the whole URL in group 1 to keep string.split() support
const urlRegex = () => (/((?:https?(?::\/\/))(?:www\.)?[a-zA-Z0-9-_.]+(?:\.[a-zA-Z0-9]{2,})(?:[-a-zA-Z0-9:%_+.~#?&//=@]*))/g);

// Get <a> element as string
const linkify = (href, options) => createHtmlElement({
	name: 'a',
	attributes: Object.assign({href: ''}, options.attributes, {href}),
	value: href
});

// Get DOM node from HTML
const domify = html => document.createRange().createContextualFragment(html);

const getAsString = (input, options) => {
	return input.replace(urlRegex(), match => linkify(match, options));
};

const getAsDocumentFragment = (input, options) => {
	return input.split(urlRegex()).reduce((frag, text, index) => {
		if (index % 2) { // URLs are always in odd positions
			frag.appendChild(domify(linkify(text, options)));
		} else if (text.length > 0) {
			frag.appendChild(document.createTextNode(text));
		}

		return frag;
	}, document.createDocumentFragment());
};

module.exports = (input, options) => {
	options = Object.assign({
		attributes: {},
		type: 'string'
	}, options);

	if (options.type === 'string') {
		return getAsString(input, options);
	}

	if (options.type === 'dom') {
		return getAsDocumentFragment(input, options);
	}

	throw new Error('The type option must be either dom or string');
};


/***/ })
/******/ ]);
//# sourceMappingURL=content.js.map